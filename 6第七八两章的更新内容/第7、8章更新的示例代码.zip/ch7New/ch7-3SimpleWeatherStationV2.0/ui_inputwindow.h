/********************************************************************************
** Form generated from reading UI file 'inputwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_INPUTWINDOW_H
#define UI_INPUTWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_InputWindow
{
public:
    QPushButton *pushButtonCancel;
    QPushButton *pushButtonOK;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QLabel *label_6;
    QLabel *label_7;
    QLineEdit *lineEditTemperature;
    QLineEdit *lineEditHumidity;
    QLineEdit *lineEditAltitude;
    QLineEdit *lineEditIllumination;
    QLineEdit *lineEditPressure;
    QLineEdit *lineEditWindSpeed;
    QLineEdit *lineEditWindDirection;

    void setupUi(QWidget *InputWindow)
    {
        if (InputWindow->objectName().isEmpty())
            InputWindow->setObjectName(QString::fromUtf8("InputWindow"));
        InputWindow->resize(499, 231);
        pushButtonCancel = new QPushButton(InputWindow);
        pushButtonCancel->setObjectName(QString::fromUtf8("pushButtonCancel"));
        pushButtonCancel->setGeometry(QRect(390, 180, 93, 28));
        QFont font;
        font.setPointSize(9);
        pushButtonCancel->setFont(font);
        pushButtonOK = new QPushButton(InputWindow);
        pushButtonOK->setObjectName(QString::fromUtf8("pushButtonOK"));
        pushButtonOK->setGeometry(QRect(280, 180, 93, 28));
        pushButtonOK->setFont(font);
        label = new QLabel(InputWindow);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(20, 20, 100, 30));
        label->setFont(font);
        label_2 = new QLabel(InputWindow);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(20, 60, 100, 30));
        label_2->setFont(font);
        label_3 = new QLabel(InputWindow);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(20, 100, 100, 30));
        label_3->setFont(font);
        label_4 = new QLabel(InputWindow);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(20, 180, 100, 30));
        label_4->setFont(font);
        label_5 = new QLabel(InputWindow);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(270, 20, 100, 30));
        label_5->setFont(font);
        label_6 = new QLabel(InputWindow);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(270, 60, 100, 30));
        label_6->setFont(font);
        label_7 = new QLabel(InputWindow);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(20, 140, 100, 30));
        label_7->setFont(font);
        lineEditTemperature = new QLineEdit(InputWindow);
        lineEditTemperature->setObjectName(QString::fromUtf8("lineEditTemperature"));
        lineEditTemperature->setGeometry(QRect(130, 20, 100, 30));
        lineEditTemperature->setFont(font);
        lineEditHumidity = new QLineEdit(InputWindow);
        lineEditHumidity->setObjectName(QString::fromUtf8("lineEditHumidity"));
        lineEditHumidity->setGeometry(QRect(130, 60, 100, 30));
        lineEditHumidity->setFont(font);
        lineEditAltitude = new QLineEdit(InputWindow);
        lineEditAltitude->setObjectName(QString::fromUtf8("lineEditAltitude"));
        lineEditAltitude->setGeometry(QRect(130, 100, 100, 30));
        lineEditAltitude->setFont(font);
        lineEditIllumination = new QLineEdit(InputWindow);
        lineEditIllumination->setObjectName(QString::fromUtf8("lineEditIllumination"));
        lineEditIllumination->setGeometry(QRect(130, 140, 100, 30));
        lineEditIllumination->setFont(font);
        lineEditPressure = new QLineEdit(InputWindow);
        lineEditPressure->setObjectName(QString::fromUtf8("lineEditPressure"));
        lineEditPressure->setGeometry(QRect(130, 180, 100, 30));
        lineEditPressure->setFont(font);
        lineEditWindSpeed = new QLineEdit(InputWindow);
        lineEditWindSpeed->setObjectName(QString::fromUtf8("lineEditWindSpeed"));
        lineEditWindSpeed->setGeometry(QRect(380, 20, 100, 30));
        lineEditWindSpeed->setFont(font);
        lineEditWindDirection = new QLineEdit(InputWindow);
        lineEditWindDirection->setObjectName(QString::fromUtf8("lineEditWindDirection"));
        lineEditWindDirection->setGeometry(QRect(380, 60, 100, 30));
        lineEditWindDirection->setFont(font);

        retranslateUi(InputWindow);

        QMetaObject::connectSlotsByName(InputWindow);
    } // setupUi

    void retranslateUi(QWidget *InputWindow)
    {
        InputWindow->setWindowTitle(QCoreApplication::translate("InputWindow", "\350\276\223\345\205\245\346\250\241\346\213\237\346\225\260\346\215\256", nullptr));
        pushButtonCancel->setText(QCoreApplication::translate("InputWindow", "\345\217\226\346\266\210", nullptr));
        pushButtonOK->setText(QCoreApplication::translate("InputWindow", "\347\241\256\345\256\232", nullptr));
        label->setText(QCoreApplication::translate("InputWindow", "\346\270\251\345\272\246\357\274\210\342\204\203\357\274\211\357\274\232", nullptr));
        label_2->setText(QCoreApplication::translate("InputWindow", "\346\271\277\345\272\246\357\274\210%RH\357\274\211\357\274\232", nullptr));
        label_3->setText(QCoreApplication::translate("InputWindow", "\346\265\267\346\213\224\357\274\210m\357\274\211\357\274\232", nullptr));
        label_4->setText(QCoreApplication::translate("InputWindow", "\346\260\224\345\216\213\357\274\210kPa\357\274\211\357\274\232", nullptr));
        label_5->setText(QCoreApplication::translate("InputWindow", "\351\243\216\351\200\237\357\274\210m/s\357\274\211\357\274\232", nullptr));
        label_6->setText(QCoreApplication::translate("InputWindow", "\351\243\216\345\220\221\357\274\210\302\260\357\274\211\357\274\232", nullptr));
        label_7->setText(QCoreApplication::translate("InputWindow", "\347\205\247\345\272\246\357\274\210klux\357\274\211\357\274\232", nullptr));
        lineEditTemperature->setText(QString());
        lineEditTemperature->setPlaceholderText(QString());
        lineEditHumidity->setText(QString());
        lineEditHumidity->setPlaceholderText(QString());
        lineEditAltitude->setText(QString());
        lineEditAltitude->setPlaceholderText(QString());
        lineEditIllumination->setText(QString());
        lineEditIllumination->setPlaceholderText(QString());
        lineEditPressure->setText(QString());
        lineEditPressure->setPlaceholderText(QString());
        lineEditWindSpeed->setText(QString());
        lineEditWindSpeed->setPlaceholderText(QString());
        lineEditWindDirection->setText(QString());
        lineEditWindDirection->setPlaceholderText(QString());
    } // retranslateUi

};

namespace Ui {
    class InputWindow: public Ui_InputWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_INPUTWINDOW_H
