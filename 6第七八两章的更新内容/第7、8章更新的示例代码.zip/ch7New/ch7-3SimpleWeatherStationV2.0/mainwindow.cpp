﻿#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "ClassGY39.h"
#include "ClassPR3000.h"
#include <QRandomGenerator>
#include <QDateTime>
#include <QSerialPort>
#include <QSerialPortInfo>
#include <QDebug>
#include <QMessageBox>
#include <QTimer>
#include <QMouseEvent>
#include <QDir>
#include <QSettings>
#include "inputwindow.h"
#include <QTcpSocket>

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent), ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    m_GY39Device = new ClassGY39();
    m_PR3000Device = new ClassPR3000();
    m_nSerialWeatherOpenedFlag = 0;
    m_nSerialWindOpenedFlag = 0;

    m_TCPSocket = new QTcpSocket();      // TCP通信
    m_serialWeather = new QSerialPort(); // 气象信息串口
    m_serialWind = new QSerialPort();    // 风速信息串口

    m_configFilePath.append(QString(QDir::currentPath() + "/config.ini"));
    readINIFile(); // 读取配置文件

    m_timerAutoGetData = new QTimer();                                                        // 初始化自动采集定时器
    m_timerAutoUpdateSerial = new QTimer();                                                   // 初始化自动更新串口信息定时器
    connect(m_timerAutoUpdateSerial, SIGNAL(timeout()), this, SLOT(slot_updateSerialInfo())); // 更新端口号
    m_timerAutoUpdateSerial->start(1000);

    connect(this, SIGNAL(signal_newDataArrived()), this, SLOT(slot_updateUI()));

    ui->imageSwitchTCP->installEventFilter(this); // 注册鼠标事件
    ui->imageSwitchAlarm->installEventFilter(this);

    ui->tabWidget->setCurrentIndex(1);

    slot_updateSerialInfo();
}

MainWindow::~MainWindow()
{
    writeINIFile();                 // 保存配置文件
    delete m_timerAutoGetData;      // 自动采集定时器
    delete m_timerAutoUpdateSerial; // 自动更新串口信息定时器
    delete m_TCPSocket;             // TCP通信
    delete m_serialWeather;         // 气象信息串口
    delete m_serialWind;            // 风速信息串口
    delete m_GY39Device;
    delete m_PR3000Device;
    delete ui;
}

void MainWindow::slot_updateSerialInfo()
{
    if (QSerialPortInfo::availablePorts().count() == ui->comboBoxUart1->count())
    {
        return;
    }

    ui->comboBoxUart1->clear();
    ui->comboBoxUart2->clear();
    printLog("检测到串口信息：");

    foreach (const QSerialPortInfo &info, QSerialPortInfo::availablePorts())
    {
        ui->comboBoxUart1->addItem(info.portName());
        ui->comboBoxUart2->addItem(info.portName());
        printLog(info.portName(), info.description());
    }

    ui->comboBoxUart1->model()->sort(0);
    ui->comboBoxUart2->model()->sort(0);
}

bool MainWindow::eventFilter(QObject *obj, QEvent *event)
{
    if (obj == ui->imageSwitchTCP)
    {
        if (event->type() == QEvent::MouseButtonPress)
        {
            QMouseEvent *event2 = static_cast<QMouseEvent *>(event);
            if (event2->button() == Qt::LeftButton)
            {
                if (!ui->imageSwitchTCP->getChecked())
                {
                    m_TCPSocket->connectToHost("127.0.0.1", 1811);
                    printLog("TCP通信已打开，数据将通过TCP协议发送到OneNet平台");
                    connect(this, SIGNAL(signal_newDataArrived()), this, SLOT(slot_TCPSendToOneNET()));

                    QString AuthInfo = QString("*%1#%2#%3*").arg(ui->lineEditProductID->text()).arg(ui->lineEditAuthCode->text()).arg(ui->lineEditScriptName->text()); // 组装登录报文

                    printLog("发送TCP验证信息", AuthInfo); // 发送登录报文
                    m_TCPSocket->write(AuthInfo.toUtf8());

                    QEventLoop eventLoop;
                    connect(m_TCPSocket, SIGNAL(readyRead()), &eventLoop, SLOT(quit()));
                    QTimer::singleShot(2000, &eventLoop, SLOT(quit()));
                    eventLoop.exec();
                    disconnect(m_TCPSocket, SIGNAL(readyRead()), &eventLoop, SLOT(quit()));

                    QByteArray buffer = m_TCPSocket->readAll();
                    printLog("服务器返回", buffer);
                }
                else
                {
                    m_TCPSocket->close();
                    printLog("TCP通信已关闭");
                    disconnect(this, SIGNAL(signal_newDataArrived()), this, SLOT(slot_TCPSendToOneNET()));
                }
            }
        }
    }

    if (obj == ui->imageSwitchAlarm) // 是否是报警控件发生事件
    {
        if (event->type() == QEvent::MouseButtonPress) // 是否是鼠标事件
        {
            QMouseEvent *event2 = static_cast<QMouseEvent *>(event); // 将基类指针赋值给派生类指针
            if (event2->button() == Qt::LeftButton)                  // 是否是左键单击
            {
                if (!ui->imageSwitchAlarm->getChecked()) // 如果启用了报警功能
                {
                    connect(this, SIGNAL(signal_newDataArrived()), this, SLOT(slot_alarm())); // 连接槽函数
                    printLog("启用报警功能");
                }
                else
                {
                    disconnect(this, SIGNAL(signal_newDataArrived()), this, SLOT(slot_alarm())); // 断开槽函数
                    ui->lightPoint->setBgColor(QColor(0, 255, 0));                               // 关闭指示灯
                    ui->lightPoint->setStep(0);
                    printLog("关闭报警功能");
                }
            }
        }
    }
    return QObject::eventFilter(obj, event);
}

void MainWindow::slot_TCPSendToOneNET()
{
    QByteArray qbaDataToSend;

    qbaDataToSend = m_GY39Device->dataToHex();
    qbaDataToSend.append(m_PR3000Device->dataToHex());
    printLog("发送TCP数据", qByteToStr(qbaDataToSend));
    m_TCPSocket->write(qbaDataToSend);

    QEventLoop eventLoop;
    connect(m_TCPSocket, SIGNAL(readyRead()), &eventLoop, SLOT(quit()));
    QTimer::singleShot(1000, &eventLoop, SLOT(quit()));
    eventLoop.exec();
    disconnect(m_TCPSocket, SIGNAL(readyRead()), &eventLoop, SLOT(quit()));

    QByteArray qbaResponse = m_TCPSocket->readAll();
    printLog("服务器返回", qbaResponse);
}

QString MainWindow::qByteToStr(QByteArray qbaData)
{
    QString qstrTemp = qbaData.toHex().toUpper(); // 转换为16进制数，并大写
    QString qstrTemp1;
    for (int i = 0; i < qstrTemp.length(); i += 2) // 整理字符串，即添加空格
    {
        qstrTemp1 += qstrTemp.mid(i, 2);
        qstrTemp1 += " ";
    }
    return qstrTemp1;
}

void MainWindow::slot_autoGetData_Timeout()
{
    on_pushButtonGetHardwareData_clicked();
}

void MainWindow::on_pushButtonGetRandomData_clicked()
{
    int nSeed = QDateTime::currentDateTime().toSecsSinceEpoch();
    QRandomGenerator generator(nSeed);

    m_GY39Device->setIllumination(generator.bounded(0, 200000));
    m_GY39Device->setTemperature(generator.bounded(-20, 45));
    m_GY39Device->setPressure(generator.bounded(90000, 110000) / 1000.0);
    m_GY39Device->setHumidity(generator.bounded(0, 100));
    m_GY39Device->setAltitude(generator.bounded(-200, 9000));

    m_PR3000Device->setWindSpeed(generator.bounded(0, 20));
    m_PR3000Device->setWindDirection(generator.bounded(0, 359));

    printLog("生成模拟数据", QString("温度%1℃，湿度%2%RH，海拔%3m，气压%4kPa，照度%5lux，风速%6m/s，风向%7°")
                                 .arg(m_GY39Device->getTemperature())
                                 .arg(m_GY39Device->getHumidity())
                                 .arg(m_GY39Device->getAltitude())
                                 .arg(m_GY39Device->getPressure())
                                 .arg(m_GY39Device->getIllumination())
                                 .arg(m_PR3000Device->getWindSpeed())
                                 .arg(m_PR3000Device->getWindDirection()));
    emit signal_newDataArrived();
}

void MainWindow::on_pushButtonOpenUart1_clicked()
{
    if (ui->pushButtonOpenUart1->text() == "打开串口1") // 判断当前串口的状态
    {
        // 初始化气象信息串口
        m_serialWeather->setPortName(ui->comboBoxUart1->currentText());      // 选取串口
        m_serialWeather->setBaudRate(ui->lineEditBaudRate1->text().toInt()); // 波特率
        m_serialWeather->setDataBits(QSerialPort::Data8);                    // 数据位数
        m_serialWeather->setParity(QSerialPort::NoParity);                   // 奇偶校验类型
        m_serialWeather->setStopBits(QSerialPort::OneStop);                  // 停止位数
        m_serialWeather->setFlowControl(QSerialPort::NoFlowControl);         // 流控制
        m_serialWeather->open(QIODevice::ReadWrite);                         // 打开串口

        if (m_serialWeather->isOpen())
        {
            printLog("串口1已打开", ui->comboBoxUart1->currentText());
            ui->pushButtonOpenUart1->setText("关闭串口1");
            m_nSerialWeatherOpenedFlag = 1;
        }
        else
        {
            printLog("串口1打开失败");
        }
    }
    else
    {
        printLog("串口1已关闭");
        ui->pushButtonOpenUart1->setText("打开串口1");
        m_nSerialWeatherOpenedFlag = 0;
        m_serialWeather->close();
    }

    if (m_nSerialWindOpenedFlag + m_nSerialWeatherOpenedFlag > 0)
    {
        disconnect(m_timerAutoUpdateSerial, SIGNAL(timeout()), this, SLOT(slot_updateSerialInfo()));
    }
    else
    {
        connect(m_timerAutoUpdateSerial, SIGNAL(timeout()), this, SLOT(slot_updateSerialInfo()));
    }
}

void MainWindow::on_pushButtonOpenUart2_clicked()
{
    if (ui->pushButtonOpenUart2->text() == "打开串口2") // 判断当前串口的状态
    {
        // 初始化风速信息串口
        m_serialWind->setPortName(ui->comboBoxUart2->currentText());      // 选取串口
        m_serialWind->setBaudRate(ui->lineEditBaudRate2->text().toInt()); // 波特率
        m_serialWind->setDataBits(QSerialPort::Data8);                    // 数据位数
        m_serialWind->setParity(QSerialPort::NoParity);                   // 奇偶校验类型
        m_serialWind->setStopBits(QSerialPort::OneStop);                  // 停止位
        m_serialWind->setFlowControl(QSerialPort::NoFlowControl);         // 流控制
        m_serialWind->open(QIODevice::ReadWrite);                         // 打开串口

        if (m_serialWind->isOpen())

        {
            printLog("串口2已打开", ui->comboBoxUart2->currentText());
            ui->pushButtonOpenUart2->setText("关闭串口2");
            m_nSerialWindOpenedFlag = 1;
        }
        else
        {
            printLog("串口2打开失败");
        }
    }
    else
    {
        ui->pushButtonOpenUart2->setText("打开串口2");
        printLog("串口2已关闭", "");
        m_nSerialWindOpenedFlag = 0;
        m_serialWind->close();
    }

    if (m_nSerialWindOpenedFlag + m_nSerialWeatherOpenedFlag > 0)
    {
        disconnect(m_timerAutoUpdateSerial, SIGNAL(timeout()), this, SLOT(slot_updateSerialInfo()));
    }
    else
    {
        connect(m_timerAutoUpdateSerial, SIGNAL(timeout()), this, SLOT(slot_updateSerialInfo()));
    }
}

void MainWindow::on_pushButtonGetHardwareData_clicked()
{
    int nGY39DataValidFlag = -1, nPR3000DataValidFlag = -1;
    if (m_nSerialWeatherOpenedFlag == 1)
    {
        nGY39DataValidFlag = m_GY39Device->readSerialData(m_serialWeather);
        switch (nGY39DataValidFlag)
        {
        case -1:
            printLog("串口1数据长度不正确");
            break;
        case -2:
            printLog("串口1数据校验错误");
            break;
        }
    }

    if (m_nSerialWindOpenedFlag == 1)
    {
        nPR3000DataValidFlag = m_PR3000Device->readSerialData(m_serialWind);
        switch (nPR3000DataValidFlag)
        {
        case -1:
            printLog("串口2风速数据校验错误");
            break;
        case -2:
            printLog("串口2风速结果不符合范围限值");
            break;
        case -3:
            printLog("串口2风向数据校验错误");
            break;
        case -4:
            printLog("串口2风向结果不符合范围限值");
            break;
        }
    }

    if ((nGY39DataValidFlag == 0) || (nPR3000DataValidFlag == 0))
    {
        printLog("读取硬件数据", QString("温度%1℃，湿度%2%RH，海拔%3m，气压%4kPa，照度%5lux，风速%6m/s，风向%7°")
                                     .arg(m_GY39Device->getTemperature())
                                     .arg(m_GY39Device->getHumidity())
                                     .arg(m_GY39Device->getAltitude())
                                     .arg(m_GY39Device->getPressure())
                                     .arg(m_GY39Device->getIllumination())
                                     .arg(m_PR3000Device->getWindSpeed())
                                     .arg(m_PR3000Device->getWindDirection()));
        emit signal_newDataArrived();
    }
}

void MainWindow::printLog(QString log1, QString log2)
{
    QString time = QDateTime::currentDateTime().time().toString();     // 获取当前时间
    QString log = QString("%1  %2  %3").arg(time).arg(log1).arg(log2); // 生成日志内容
    ui->textEditLog->append(log);                                      // 输出日志
}

void MainWindow::slot_alarm()
{
    int nAlarmFlag = 0; // 标志位，不为零则需要报警
    QByteArray qbaLogText;

    if (m_GY39Device->getTemperature() > ui->xsliderTemperatureLimit->value())
    {
        nAlarmFlag = 1;
        qbaLogText.append("温度 ");
    }
    if (m_GY39Device->getIllumination() > ui->xsliderIlluminationLimit->value() * 1000)
    {
        nAlarmFlag = 1;
        qbaLogText.append("照度 ");
    }
    if (m_PR3000Device->getWindSpeed() > ui->xsliderWindSpeedLimit->value())
    {
        nAlarmFlag = 1;
        qbaLogText.append("风速 ");
    }

    if (nAlarmFlag == 1)
    {
        ui->lightPoint->setBgColor(QColor(255, 0, 0)); // 指示灯设为红色
        ui->lightPoint->setStep(10);                   // 指示灯闪烁
        printLog(qbaLogText, "超过限值，正在报警");
    }
    else
    {
        ui->lightPoint->setBgColor(QColor(0, 255, 0)); // 指示灯设为绿色
        ui->lightPoint->setStep(0);                    // 指示灯停止闪烁
    }
}

void MainWindow::slot_updateUI()
{
    ui->gaugeSimpleHumidity->setValue(m_GY39Device->getHumidity());                 // 湿度
    ui->gaugeSimpleTemperature->setValue(m_GY39Device->getTemperature());           // 温度
    ui->gaugeSimpleWindSpeed->setValue(m_PR3000Device->getWindSpeed());             // 风速
    ui->gaugeCompassPanWindDirection->setValue(m_PR3000Device->getWindDirection()); // 风向

    ui->navLabelPressure->setText(QString::number(m_GY39Device->getPressure(), 'f', 3)); // 气压
    ui->navLabelIllumination->setText(QString::number(m_GY39Device->getIllumination())); // 照度
    ui->navLabelAltitude->setText(QString::number(m_GY39Device->getAltitude()));         // 海拔

    ui->waveChartTemperature->addData(m_GY39Device->getTemperature());
    ui->waveChartHumidity->addData(m_GY39Device->getHumidity());
    ui->waveChartIllumination->addData(m_GY39Device->getIllumination() / 1000);
    ui->waveChartWindSpeed->addData(m_PR3000Device->getWindSpeed());
}

void MainWindow::on_radioButtonAutoMode_clicked()
{
    printLog("切换到自动模式，每2秒读取一次数据");
    ui->pushButtonGetHardwareData->setDisabled(true);
    connect(m_timerAutoGetData, SIGNAL(timeout()), this, SLOT(slot_autoGetData_Timeout()));
    m_timerAutoGetData->start(2000);
}

void MainWindow::on_radioButtonManualMode_clicked()
{
    printLog("切换到手动模式");
    ui->pushButtonGetHardwareData->setDisabled(false);
    m_timerAutoGetData->stop();
    disconnect(m_timerAutoGetData, SIGNAL(timeout()), this, SLOT(slot_AutoGetData_Timeout()));
}

void MainWindow::on_pushButtonClearLog_clicked()
{
    ui->textEditLog->clear();
}

void MainWindow::readINIFile()
{
    QSettings settings(m_configFilePath, QSettings::Format::IniFormat);

    settings.beginGroup("Baud"); // 波特率配置
    if (settings.contains("UART1"))
    {
        int nTemp = settings.value("UART1").toInt();
        ui->lineEditBaudRate1->setText(QString::number(nTemp));
    }
    else
    {
        ui->lineEditBaudRate1->setText("9600");
    }

    if (settings.contains("UART2"))
    {
        int nTemp = settings.value("UART2").toInt();
        ui->lineEditBaudRate2->setText(QString::number(nTemp));
    }
    else
    {
        ui->lineEditBaudRate2->setText("4800");
    }
    settings.endGroup();

    settings.beginGroup("Alarm");       // 报警限值
    if (settings.contains("WindSpeed")) // 风速
    {
        int nTemp = settings.value("WindSpeed").toInt();
        ui->xsliderWindSpeedLimit->setValue(nTemp);
    }
    else
    {
        ui->xsliderWindSpeedLimit->setValue(5);
    }

    if (settings.contains("Temperature")) // 温度
    {
        int nTemp = settings.value("Temperature").toInt();
        ui->xsliderTemperatureLimit->setValue(nTemp);
    }
    else
    {
        ui->xsliderTemperatureLimit->setValue(30);
    }

    if (settings.contains("Illumination")) // 照度
    {
        int nTemp = settings.value("Illumination").toInt();
        ui->xsliderIlluminationLimit->setValue(nTemp);
    }
    else
    {
        ui->xsliderIlluminationLimit->setValue(50);
    }
    settings.endGroup();

    settings.beginGroup("TCP"); // TCP配置
    if (settings.contains("ProductID"))
    {
        QString qstrTemp = settings.value("ProductID").toString();
        ui->lineEditProductID->setText(qstrTemp);
    }

    if (settings.contains("AuthCode"))
    {
        QString qstrTemp = settings.value("AuthCode").toString();
        ui->lineEditAuthCode->setText(qstrTemp);
    }

    if (settings.contains("ScriptName"))
    {
        QString qstrTemp = settings.value("ScriptName").toString();
        ui->lineEditScriptName->setText(qstrTemp);
    }
    settings.endGroup();

    printLog("已读取配置文件");
}

void MainWindow::writeINIFile()
{
    QSettings settings(m_configFilePath, QSettings::Format::IniFormat);

    settings.beginGroup("Baud"); // 波特率配置
    settings.setValue("UART1", ui->lineEditBaudRate1->text());
    settings.setValue("UART2", ui->lineEditBaudRate2->text());
    settings.endGroup();

    settings.beginGroup("Alarm"); // 报警限值
    settings.setValue("WindSpeed", ui->xsliderWindSpeedLimit->value());
    settings.setValue("Temperature", ui->xsliderTemperatureLimit->value());
    settings.setValue("Illumination", ui->xsliderIlluminationLimit->value());
    settings.endGroup();

    settings.beginGroup("TCP"); // TCP配置
    settings.setValue("ProductID", ui->lineEditProductID->text());
    settings.setValue("AuthCode", ui->lineEditAuthCode->text());
    settings.setValue("ScriptName", ui->lineEditScriptName->text());
    settings.endGroup();

    printLog("配置文件已保存");
}

void MainWindow::on_pushButtonGetInputData_clicked()
{
    InputWindow *w = new InputWindow();
    w->setAttribute(Qt::WA_DeleteOnClose, true);
    w->setAttribute(Qt::WA_QuitOnClose, false); // 防止主窗口关闭了，但是子窗口还显示在桌面上
    connect(w, SIGNAL(signal_sendDataToMainWindow(int, ClassGY39 &, ClassPR3000 &)), this, SLOT(slot_getInputData(int, ClassGY39 &, ClassPR3000 &)));
    w->show();
    w->showDataFromMainWindow(*m_GY39Device, *m_PR3000Device);
    ui->pushButtonGetInputData->setDisabled(1);
}

void MainWindow::slot_getInputData(int nFlag, ClassGY39 &info39, ClassPR3000 &info3000)
{
    if (nFlag == 1)
    {
        m_GY39Device->setIllumination(info39.getIllumination());
        m_GY39Device->setTemperature(info39.getTemperature());
        m_GY39Device->setPressure(info39.getPressure());
        m_GY39Device->setHumidity(info39.getHumidity());
        m_GY39Device->setAltitude(info39.getAltitude());
        m_PR3000Device->setWindSpeed(info3000.getWindSpeed());
        m_PR3000Device->setWindDirection(info3000.getWindDirection());

        printLog("用户输入数据", QString("温度%1℃，湿度%2%RH，海拔%3m，气压%4kPa，照度%5lux，风速%6m/s，风向%7°")
                                     .arg(m_GY39Device->getTemperature())
                                     .arg(m_GY39Device->getHumidity())
                                     .arg(m_GY39Device->getAltitude())
                                     .arg(m_GY39Device->getPressure())
                                     .arg(m_GY39Device->getIllumination())
                                     .arg(m_PR3000Device->getWindSpeed())
                                     .arg(m_PR3000Device->getWindDirection()));
        emit signal_newDataArrived();
    }
    ui->pushButtonGetInputData->setEnabled(1);
}

void MainWindow::on_menuReadINI_triggered()
{
    readINIFile();
}

void MainWindow::on_menuWriteINI_triggered()
{
    writeINIFile();
}

void MainWindow::on_menuExit_triggered()
{
    this->close();
}

void MainWindow::on_menuAbout_triggered()
{
    QMessageBox::information(this,
                             "关于",
                             "简易气象站V2.0\r\n——金陵科技学院电子信息工程学院");
}

void MainWindow::on_menuGetHardwareData_triggered()
{
    on_pushButtonGetHardwareData_clicked();
}

void MainWindow::on_menuGetRandomData_triggered()
{
    on_pushButtonGetRandomData_clicked();
}

void MainWindow::on_menuGetInputData_triggered()
{
    on_pushButtonGetInputData_clicked();
}

void MainWindow::on_pushButtonClearCharts_clicked()
{
    ui->waveChartTemperature->clearData();
    ui->waveChartHumidity->clearData();
    ui->waveChartIllumination->clearData();
    ui->waveChartWindSpeed->clearData();
}
