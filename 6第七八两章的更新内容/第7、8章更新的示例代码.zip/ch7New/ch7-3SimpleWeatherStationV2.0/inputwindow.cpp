﻿#include "inputwindow.h"
#include "ui_inputwindow.h"
#include <QMessageBox>

InputWindow::InputWindow(QWidget *parent) : QWidget(parent),
                                            ui(new Ui::InputWindow)
{
    ui->setupUi(this);
}

InputWindow::~InputWindow()
{
    delete ui;
}

void InputWindow::on_pushButtonCancel_clicked()
{
    emit signal_sendDataToMainWindow(0, m_GY39InputData, m_PR3000InputData);
    this->close();
}

void InputWindow::on_pushButtonOK_clicked()
{
    m_GY39InputData.setIllumination(ui->lineEditIllumination->text().toDouble() * 1000.0);
    m_GY39InputData.setTemperature(ui->lineEditTemperature->text().toDouble());
    m_GY39InputData.setPressure(ui->lineEditPressure->text().toDouble());
    m_GY39InputData.setHumidity(ui->lineEditHumidity->text().toInt());
    m_GY39InputData.setAltitude(ui->lineEditAltitude->text().toInt());

    m_PR3000InputData.setWindSpeed(ui->lineEditWindSpeed->text().toDouble());
    m_PR3000InputData.setWindDirection(ui->lineEditWindDirection->text().toDouble());

    if (m_GY39InputData.getHumidity() < 0 || m_GY39InputData.getHumidity() > 100)
    {
        QMessageBox::warning(this, "注意！", "请输入合适的湿度值。");
        ui->lineEditHumidity->setFocus();
        ui->lineEditHumidity->selectAll();
        return;
    }

    else if (m_GY39InputData.getTemperature() < -15 || m_GY39InputData.getTemperature() > 40)
    {
        QMessageBox::warning(this, "注意！", "请输入合适的温度值。");
        ui->lineEditTemperature->setFocus();
        ui->lineEditTemperature->selectAll();
        return;
    }

    else if (m_GY39InputData.getAltitude() < -200 || m_GY39InputData.getAltitude() > 9000)
    {
        QMessageBox::warning(this, "注意！", "请输入合适的海拔。");
        ui->lineEditAltitude->setFocus();
        ui->lineEditAltitude->selectAll();
        return;
    }

    else if (m_GY39InputData.getPressure() < 90 || m_GY39InputData.getPressure() > 110)
    {
        QMessageBox::warning(this, "注意！", "请输入合适的气压。");
        ui->lineEditPressure->setFocus();
        ui->lineEditPressure->selectAll();
        return;
    }

    else if (m_GY39InputData.getIllumination() < 0 || m_GY39InputData.getIllumination() > 400000)
    {
        QMessageBox::warning(this, "注意！", "请输入合适的照度。");
        ui->lineEditIllumination->setFocus();
        ui->lineEditIllumination->selectAll();
        return;
    }

    else if (m_PR3000InputData.getWindSpeed() < 0 || m_PR3000InputData.getWindSpeed() > 30)
    {
        QMessageBox::warning(this, "注意！", "请输入合适的风速。");
        ui->lineEditWindSpeed->setFocus();
        ui->lineEditWindSpeed->selectAll();
        return;
    }

    else if (m_PR3000InputData.getWindDirection() < 0 || m_PR3000InputData.getWindDirection() > 360)
    {
        QMessageBox::warning(this, "注意！", "请输入合适的风向值。");
        ui->lineEditWindDirection->setFocus();
        ui->lineEditWindDirection->selectAll();
        return;
    }

    emit signal_sendDataToMainWindow(1, m_GY39InputData, m_PR3000InputData);
    this->close();
}

void InputWindow::showDataFromMainWindow(ClassGY39 &info39, ClassPR3000 &info3000)
{
    ui->lineEditIllumination->setText(QString::number(info39.getIllumination() / 1000));
    ui->lineEditTemperature->setText(QString::number(info39.getTemperature()));
    ui->lineEditPressure->setText(QString::number(info39.getPressure()));
    ui->lineEditHumidity->setText(QString::number(info39.getHumidity()));
    ui->lineEditAltitude->setText(QString::number(info39.getAltitude()));
    ui->lineEditWindSpeed->setText(QString::number(info3000.getWindSpeed()));
    ui->lineEditWindDirection->setText(QString::number(info3000.getWindDirection()));
}

void InputWindow::closeEvent(QCloseEvent *event)
{
    emit signal_sendDataToMainWindow(0, m_GY39InputData, m_PR3000InputData);
}
