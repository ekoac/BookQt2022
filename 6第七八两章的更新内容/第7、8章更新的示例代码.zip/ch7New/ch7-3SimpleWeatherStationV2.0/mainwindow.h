﻿#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "ClassGY39.h"
#include "ClassPR3000.h"
#include "inputwindow.h"
#include <QTcpSocket>

QT_BEGIN_NAMESPACE
namespace Ui
{
    class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

private:
    Ui::MainWindow *ui;

    ClassGY39 *m_GY39Device;
    ClassPR3000 *m_PR3000Device;

    QSerialPort *m_serialWeather;
    QSerialPort *m_serialWind;
    int m_nSerialWeatherOpenedFlag;
    int m_nSerialWindOpenedFlag;

    QTimer *m_timerAutoGetData;
    QTimer *m_timerAutoUpdateSerial;

    QString m_configFilePath;

    QTcpSocket *m_TCPSocket;

    void readINIFile();
    void writeINIFile();

    QString qByteToStr(QByteArray str);
    void printLog(QString log1, QString log2 = "");

    bool eventFilter(QObject *obj, QEvent *event);

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_pushButtonGetRandomData_clicked();
    void on_pushButtonGetHardwareData_clicked();
    void on_pushButtonClearLog_clicked();
    void on_pushButtonOpenUart1_clicked();
    void on_pushButtonOpenUart2_clicked();
    void on_pushButtonGetInputData_clicked();
    void on_pushButtonClearCharts_clicked();
    void on_radioButtonAutoMode_clicked();
    void on_radioButtonManualMode_clicked();

    void slot_updateSerialInfo();
    void slot_getInputData(int nFlag, ClassGY39 &info1, ClassPR3000 &info3000);
    void slot_TCPSendToOneNET();
    void slot_alarm();
    void slot_updateUI();
    void slot_autoGetData_Timeout();

    void on_menuReadINI_triggered();
    void on_menuWriteINI_triggered();
    void on_menuExit_triggered();
    void on_menuAbout_triggered();
    void on_menuGetHardwareData_triggered();
    void on_menuGetRandomData_triggered();
    void on_menuGetInputData_triggered();

signals:
    void signal_newDataArrived();
};
#endif // MAINWINDOW_H
