/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>
#include "gaugecompasspan.h"
#include "gaugesimple.h"
#include "imageswitch.h"
#include "lightpoint.h"
#include "navlabel.h"
#include "wavechart.h"
#include "xslider.h"

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *menuReadINI;
    QAction *menuWriteINI;
    QAction *menuAbout;
    QAction *menuExit;
    QAction *menuGetHardwareData;
    QAction *menuGetRandomData;
    QAction *menuGetInputData;
    QWidget *centralwidget;
    QGroupBox *groupBoxPorts;
    QLabel *label_6;
    QComboBox *comboBoxUart1;
    QLabel *label_7;
    QLineEdit *lineEditBaudRate1;
    QPushButton *pushButtonOpenUart1;
    QComboBox *comboBoxUart2;
    QLineEdit *lineEditBaudRate2;
    QLabel *label_11;
    QLabel *label_12;
    QPushButton *pushButtonOpenUart2;
    QGroupBox *groupBox_4;
    QRadioButton *radioButtonManualMode;
    QRadioButton *radioButtonAutoMode;
    QPushButton *pushButtonGetHardwareData;
    QPushButton *pushButtonGetRandomData;
    QPushButton *pushButtonGetInputData;
    QTabWidget *tabWidget;
    QWidget *tab;
    QGroupBox *groupBoxWeatherInfo;
    GaugeCompassPan *gaugeCompassPanWindDirection;
    QLabel *label_5;
    GaugeSimple *gaugeSimpleHumidity;
    GaugeSimple *gaugeSimpleTemperature;
    GaugeSimple *gaugeSimpleWindSpeed;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    NavLabel *navLabel;
    NavLabel *navLabelPressure;
    NavLabel *navLabel_2;
    NavLabel *navLabelIllumination;
    NavLabel *navLabelAltitude;
    NavLabel *navLabel_3;
    QFrame *line;
    QGroupBox *groupBoxTCP;
    ImageSwitch *imageSwitchTCP;
    QLineEdit *lineEditScriptName;
    QLabel *label_18;
    QLineEdit *lineEditAuthCode;
    QLineEdit *lineEditProductID;
    QLabel *label_16;
    QLabel *label_17;
    QGroupBox *groupBoxHTTP;
    ImageSwitch *imageSwitchHTTP;
    QLabel *label_14;
    QLabel *label_15;
    QLineEdit *lineEditDeviceID;
    QLineEdit *lineEditAPIKey;
    QGroupBox *groupBoxAlarm;
    LightPoint *lightPoint;
    ImageSwitch *imageSwitchAlarm;
    QLabel *label_8;
    XSlider *xsliderWindSpeedLimit;
    XSlider *xsliderTemperatureLimit;
    QLabel *label_9;
    QLabel *label_10;
    XSlider *xsliderIlluminationLimit;
    QTextEdit *textEditLog;
    QPushButton *pushButtonClearLog;
    QWidget *tab_2;
    WaveChart *waveChartTemperature;
    QLabel *label_21;
    WaveChart *waveChartHumidity;
    WaveChart *waveChartWindSpeed;
    WaveChart *waveChartIllumination;
    QLabel *label_22;
    QLabel *label_23;
    QLabel *label_24;
    QPushButton *pushButtonClearCharts;
    QMenuBar *menubar;
    QMenu *menuFile;
    QMenu *menuAbout_2;
    QMenu *menuData;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(1039, 917);
        QFont font;
        font.setPointSize(9);
        MainWindow->setFont(font);
        QIcon icon;
        icon.addFile(QString::fromUtf8("icon.png"), QSize(), QIcon::Normal, QIcon::Off);
        MainWindow->setWindowIcon(icon);
        MainWindow->setAutoFillBackground(false);
        menuReadINI = new QAction(MainWindow);
        menuReadINI->setObjectName(QString::fromUtf8("menuReadINI"));
        menuReadINI->setShortcutContext(Qt::WindowShortcut);
        menuWriteINI = new QAction(MainWindow);
        menuWriteINI->setObjectName(QString::fromUtf8("menuWriteINI"));
        menuWriteINI->setShortcutContext(Qt::WindowShortcut);
        menuAbout = new QAction(MainWindow);
        menuAbout->setObjectName(QString::fromUtf8("menuAbout"));
        menuAbout->setShortcutContext(Qt::WindowShortcut);
        menuExit = new QAction(MainWindow);
        menuExit->setObjectName(QString::fromUtf8("menuExit"));
        menuExit->setShortcutContext(Qt::WindowShortcut);
        menuGetHardwareData = new QAction(MainWindow);
        menuGetHardwareData->setObjectName(QString::fromUtf8("menuGetHardwareData"));
        menuGetHardwareData->setEnabled(false);
        menuGetHardwareData->setShortcutContext(Qt::WindowShortcut);
        menuGetRandomData = new QAction(MainWindow);
        menuGetRandomData->setObjectName(QString::fromUtf8("menuGetRandomData"));
        menuGetInputData = new QAction(MainWindow);
        menuGetInputData->setObjectName(QString::fromUtf8("menuGetInputData"));
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        groupBoxPorts = new QGroupBox(centralwidget);
        groupBoxPorts->setObjectName(QString::fromUtf8("groupBoxPorts"));
        groupBoxPorts->setGeometry(QRect(10, 20, 631, 141));
        QFont font1;
        font1.setPointSize(9);
        font1.setKerning(false);
        groupBoxPorts->setFont(font1);
        label_6 = new QLabel(groupBoxPorts);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(10, 30, 131, 30));
        label_6->setFont(font1);
        label_6->setAlignment(Qt::AlignCenter);
        comboBoxUart1 = new QComboBox(groupBoxPorts);
        comboBoxUart1->setObjectName(QString::fromUtf8("comboBoxUart1"));
        comboBoxUart1->setEnabled(true);
        comboBoxUart1->setGeometry(QRect(130, 30, 121, 30));
        label_7 = new QLabel(groupBoxPorts);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(290, 30, 271, 30));
        label_7->setFont(font1);
        label_7->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        lineEditBaudRate1 = new QLineEdit(groupBoxPorts);
        lineEditBaudRate1->setObjectName(QString::fromUtf8("lineEditBaudRate1"));
        lineEditBaudRate1->setGeometry(QRect(350, 30, 81, 30));
        lineEditBaudRate1->setFont(font1);
        lineEditBaudRate1->setAlignment(Qt::AlignCenter);
        pushButtonOpenUart1 = new QPushButton(groupBoxPorts);
        pushButtonOpenUart1->setObjectName(QString::fromUtf8("pushButtonOpenUart1"));
        pushButtonOpenUart1->setGeometry(QRect(490, 30, 121, 30));
        pushButtonOpenUart1->setFont(font1);
        comboBoxUart2 = new QComboBox(groupBoxPorts);
        comboBoxUart2->setObjectName(QString::fromUtf8("comboBoxUart2"));
        comboBoxUart2->setEnabled(true);
        comboBoxUart2->setGeometry(QRect(130, 80, 121, 30));
        lineEditBaudRate2 = new QLineEdit(groupBoxPorts);
        lineEditBaudRate2->setObjectName(QString::fromUtf8("lineEditBaudRate2"));
        lineEditBaudRate2->setGeometry(QRect(350, 80, 81, 30));
        lineEditBaudRate2->setFont(font1);
        lineEditBaudRate2->setAlignment(Qt::AlignCenter);
        label_11 = new QLabel(groupBoxPorts);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        label_11->setGeometry(QRect(290, 80, 261, 30));
        label_11->setFont(font1);
        label_11->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        label_12 = new QLabel(groupBoxPorts);
        label_12->setObjectName(QString::fromUtf8("label_12"));
        label_12->setGeometry(QRect(10, 80, 131, 30));
        label_12->setFont(font1);
        label_12->setAlignment(Qt::AlignCenter);
        pushButtonOpenUart2 = new QPushButton(groupBoxPorts);
        pushButtonOpenUart2->setObjectName(QString::fromUtf8("pushButtonOpenUart2"));
        pushButtonOpenUart2->setGeometry(QRect(490, 80, 121, 30));
        pushButtonOpenUart2->setFont(font1);
        label_11->raise();
        label_6->raise();
        comboBoxUart1->raise();
        label_7->raise();
        lineEditBaudRate1->raise();
        pushButtonOpenUart1->raise();
        comboBoxUart2->raise();
        lineEditBaudRate2->raise();
        label_12->raise();
        pushButtonOpenUart2->raise();
        groupBox_4 = new QGroupBox(centralwidget);
        groupBox_4->setObjectName(QString::fromUtf8("groupBox_4"));
        groupBox_4->setGeometry(QRect(660, 20, 371, 141));
        groupBox_4->setFont(font);
        radioButtonManualMode = new QRadioButton(groupBox_4);
        radioButtonManualMode->setObjectName(QString::fromUtf8("radioButtonManualMode"));
        radioButtonManualMode->setGeometry(QRect(20, 40, 131, 30));
        radioButtonManualMode->setChecked(true);
        radioButtonAutoMode = new QRadioButton(groupBox_4);
        radioButtonAutoMode->setObjectName(QString::fromUtf8("radioButtonAutoMode"));
        radioButtonAutoMode->setGeometry(QRect(20, 80, 131, 30));
        pushButtonGetHardwareData = new QPushButton(groupBox_4);
        pushButtonGetHardwareData->setObjectName(QString::fromUtf8("pushButtonGetHardwareData"));
        pushButtonGetHardwareData->setGeometry(QRect(170, 20, 180, 30));
        pushButtonGetHardwareData->setFont(font);
        pushButtonGetRandomData = new QPushButton(groupBox_4);
        pushButtonGetRandomData->setObjectName(QString::fromUtf8("pushButtonGetRandomData"));
        pushButtonGetRandomData->setGeometry(QRect(170, 60, 180, 30));
        pushButtonGetRandomData->setFont(font);
        pushButtonGetInputData = new QPushButton(groupBox_4);
        pushButtonGetInputData->setObjectName(QString::fromUtf8("pushButtonGetInputData"));
        pushButtonGetInputData->setGeometry(QRect(170, 100, 180, 30));
        pushButtonGetInputData->setFont(font);
        tabWidget = new QTabWidget(centralwidget);
        tabWidget->setObjectName(QString::fromUtf8("tabWidget"));
        tabWidget->setGeometry(QRect(10, 180, 1021, 701));
        tab = new QWidget();
        tab->setObjectName(QString::fromUtf8("tab"));
        groupBoxWeatherInfo = new QGroupBox(tab);
        groupBoxWeatherInfo->setObjectName(QString::fromUtf8("groupBoxWeatherInfo"));
        groupBoxWeatherInfo->setGeometry(QRect(10, 20, 991, 291));
        groupBoxWeatherInfo->setFont(font);
        gaugeCompassPanWindDirection = new GaugeCompassPan(groupBoxWeatherInfo);
        gaugeCompassPanWindDirection->setObjectName(QString::fromUtf8("gaugeCompassPanWindDirection"));
        gaugeCompassPanWindDirection->setGeometry(QRect(770, 30, 200, 200));
        gaugeCompassPanWindDirection->setValue(45.000000000000000);
        gaugeCompassPanWindDirection->setBgColor(QColor(40, 45, 48, 0));
        gaugeCompassPanWindDirection->setTextColor(QColor(0, 0, 0));
        gaugeCompassPanWindDirection->setBorderWidth(8);
        label_5 = new QLabel(groupBoxWeatherInfo);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(800, 220, 131, 41));
        label_5->setFont(font);
        label_5->setAlignment(Qt::AlignCenter);
        gaugeSimpleHumidity = new GaugeSimple(groupBoxWeatherInfo);
        gaugeSimpleHumidity->setObjectName(QString::fromUtf8("gaugeSimpleHumidity"));
        gaugeSimpleHumidity->setGeometry(QRect(290, 40, 180, 180));
        gaugeSimpleHumidity->setValue(50.000000000000000);
        gaugeSimpleTemperature = new GaugeSimple(groupBoxWeatherInfo);
        gaugeSimpleTemperature->setObjectName(QString::fromUtf8("gaugeSimpleTemperature"));
        gaugeSimpleTemperature->setGeometry(QRect(50, 40, 180, 180));
        QFont font2;
        font2.setFamily(QString::fromUtf8("Arial"));
        font2.setPointSize(9);
        gaugeSimpleTemperature->setFont(font2);
        gaugeSimpleTemperature->setMinValue(-10.000000000000000);
        gaugeSimpleTemperature->setMaxValue(40.000000000000000);
        gaugeSimpleTemperature->setValue(25.000000000000000);
        gaugeSimpleWindSpeed = new GaugeSimple(groupBoxWeatherInfo);
        gaugeSimpleWindSpeed->setObjectName(QString::fromUtf8("gaugeSimpleWindSpeed"));
        gaugeSimpleWindSpeed->setGeometry(QRect(560, 50, 180, 180));
        gaugeSimpleWindSpeed->setMinValue(0.000000000000000);
        gaugeSimpleWindSpeed->setMaxValue(20.000000000000000);
        gaugeSimpleWindSpeed->setValue(2.000000000000000);
        gaugeSimpleWindSpeed->setScaleMajor(8);
        gaugeSimpleWindSpeed->setAnimation(false);
        gaugeSimpleWindSpeed->setAnimationStep(2.000000000000000);
        label = new QLabel(groupBoxWeatherInfo);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(320, 190, 131, 41));
        label->setFont(font);
        label->setAlignment(Qt::AlignCenter);
        label_2 = new QLabel(groupBoxWeatherInfo);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(80, 190, 131, 41));
        label_2->setFont(font);
        label_2->setAlignment(Qt::AlignCenter);
        label_3 = new QLabel(groupBoxWeatherInfo);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(590, 200, 131, 41));
        label_3->setFont(font);
        label_3->setAlignment(Qt::AlignCenter);
        navLabel = new NavLabel(groupBoxWeatherInfo);
        navLabel->setObjectName(QString::fromUtf8("navLabel"));
        navLabel->setGeometry(QRect(10, 240, 101, 30));
        navLabel->setBackground(QColor(100, 184, 255, 150));
        navLabel->setForeground(QColor(0, 0, 0));
        navLabel->setShowArrow(false);
        navLabel->setShowTriangle(false);
        navLabelPressure = new NavLabel(groupBoxWeatherInfo);
        navLabelPressure->setObjectName(QString::fromUtf8("navLabelPressure"));
        navLabelPressure->setGeometry(QRect(110, 240, 71, 30));
        navLabelPressure->setBackground(QColor(100, 184, 255, 150));
        navLabelPressure->setForeground(QColor(0, 0, 0));
        navLabelPressure->setShowArrow(false);
        navLabelPressure->setShowTriangle(false);
        navLabel_2 = new NavLabel(groupBoxWeatherInfo);
        navLabel_2->setObjectName(QString::fromUtf8("navLabel_2"));
        navLabel_2->setGeometry(QRect(190, 240, 101, 30));
        navLabel_2->setBackground(QColor(100, 184, 255, 150));
        navLabel_2->setForeground(QColor(0, 0, 0));
        navLabel_2->setShowArrow(false);
        navLabel_2->setShowTriangle(false);
        navLabelIllumination = new NavLabel(groupBoxWeatherInfo);
        navLabelIllumination->setObjectName(QString::fromUtf8("navLabelIllumination"));
        navLabelIllumination->setGeometry(QRect(290, 240, 71, 30));
        navLabelIllumination->setBackground(QColor(100, 184, 255, 150));
        navLabelIllumination->setForeground(QColor(0, 0, 0));
        navLabelIllumination->setShowArrow(false);
        navLabelIllumination->setShowTriangle(false);
        navLabelAltitude = new NavLabel(groupBoxWeatherInfo);
        navLabelAltitude->setObjectName(QString::fromUtf8("navLabelAltitude"));
        navLabelAltitude->setGeometry(QRect(450, 240, 61, 30));
        navLabelAltitude->setBackground(QColor(100, 184, 255, 150));
        navLabelAltitude->setForeground(QColor(0, 0, 0));
        navLabelAltitude->setShowArrow(false);
        navLabelAltitude->setShowTriangle(false);
        navLabel_3 = new NavLabel(groupBoxWeatherInfo);
        navLabel_3->setObjectName(QString::fromUtf8("navLabel_3"));
        navLabel_3->setGeometry(QRect(370, 240, 81, 30));
        navLabel_3->setBackground(QColor(100, 184, 255, 150));
        navLabel_3->setForeground(QColor(0, 0, 0));
        navLabel_3->setShowArrow(false);
        navLabel_3->setShowTriangle(false);
        line = new QFrame(groupBoxWeatherInfo);
        line->setObjectName(QString::fromUtf8("line"));
        line->setGeometry(QRect(510, 20, 20, 251));
        line->setFrameShape(QFrame::VLine);
        line->setFrameShadow(QFrame::Sunken);
        gaugeCompassPanWindDirection->raise();
        gaugeSimpleHumidity->raise();
        gaugeSimpleTemperature->raise();
        gaugeSimpleWindSpeed->raise();
        label->raise();
        label_2->raise();
        label_3->raise();
        label_5->raise();
        navLabelPressure->raise();
        navLabel->raise();
        navLabelIllumination->raise();
        navLabelAltitude->raise();
        line->raise();
        navLabel_2->raise();
        navLabel_3->raise();
        groupBoxTCP = new QGroupBox(tab);
        groupBoxTCP->setObjectName(QString::fromUtf8("groupBoxTCP"));
        groupBoxTCP->setGeometry(QRect(520, 330, 221, 171));
        groupBoxTCP->setFont(font);
        imageSwitchTCP = new ImageSwitch(groupBoxTCP);
        imageSwitchTCP->setObjectName(QString::fromUtf8("imageSwitchTCP"));
        imageSwitchTCP->setGeometry(QRect(120, 0, 87, 28));
        imageSwitchTCP->setButtonStyle(ImageSwitch::ButtonStyle_1);
        lineEditScriptName = new QLineEdit(groupBoxTCP);
        lineEditScriptName->setObjectName(QString::fromUtf8("lineEditScriptName"));
        lineEditScriptName->setGeometry(QRect(110, 130, 101, 30));
        lineEditScriptName->setFont(font);
        lineEditScriptName->setEchoMode(QLineEdit::Normal);
        lineEditScriptName->setAlignment(Qt::AlignCenter);
        label_18 = new QLabel(groupBoxTCP);
        label_18->setObjectName(QString::fromUtf8("label_18"));
        label_18->setGeometry(QRect(20, 130, 91, 30));
        label_18->setFont(font);
        label_18->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        lineEditAuthCode = new QLineEdit(groupBoxTCP);
        lineEditAuthCode->setObjectName(QString::fromUtf8("lineEditAuthCode"));
        lineEditAuthCode->setGeometry(QRect(110, 90, 101, 30));
        lineEditAuthCode->setFont(font);
        lineEditAuthCode->setEchoMode(QLineEdit::PasswordEchoOnEdit);
        lineEditAuthCode->setAlignment(Qt::AlignCenter);
        lineEditProductID = new QLineEdit(groupBoxTCP);
        lineEditProductID->setObjectName(QString::fromUtf8("lineEditProductID"));
        lineEditProductID->setGeometry(QRect(110, 50, 101, 30));
        lineEditProductID->setFont(font);
        lineEditProductID->setAlignment(Qt::AlignCenter);
        label_16 = new QLabel(groupBoxTCP);
        label_16->setObjectName(QString::fromUtf8("label_16"));
        label_16->setGeometry(QRect(20, 50, 81, 30));
        label_16->setFont(font);
        label_16->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        label_17 = new QLabel(groupBoxTCP);
        label_17->setObjectName(QString::fromUtf8("label_17"));
        label_17->setGeometry(QRect(20, 90, 81, 30));
        label_17->setFont(font);
        label_17->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        groupBoxHTTP = new QGroupBox(tab);
        groupBoxHTTP->setObjectName(QString::fromUtf8("groupBoxHTTP"));
        groupBoxHTTP->setGeometry(QRect(760, 330, 241, 171));
        groupBoxHTTP->setFont(font);
        imageSwitchHTTP = new ImageSwitch(groupBoxHTTP);
        imageSwitchHTTP->setObjectName(QString::fromUtf8("imageSwitchHTTP"));
        imageSwitchHTTP->setGeometry(QRect(130, 0, 87, 28));
        imageSwitchHTTP->setButtonStyle(ImageSwitch::ButtonStyle_1);
        label_14 = new QLabel(groupBoxHTTP);
        label_14->setObjectName(QString::fromUtf8("label_14"));
        label_14->setGeometry(QRect(20, 50, 71, 30));
        label_14->setFont(font);
        label_14->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        label_15 = new QLabel(groupBoxHTTP);
        label_15->setObjectName(QString::fromUtf8("label_15"));
        label_15->setGeometry(QRect(20, 90, 81, 30));
        label_15->setFont(font);
        label_15->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        lineEditDeviceID = new QLineEdit(groupBoxHTTP);
        lineEditDeviceID->setObjectName(QString::fromUtf8("lineEditDeviceID"));
        lineEditDeviceID->setGeometry(QRect(100, 50, 121, 30));
        lineEditDeviceID->setFont(font);
        lineEditDeviceID->setAlignment(Qt::AlignCenter);
        lineEditAPIKey = new QLineEdit(groupBoxHTTP);
        lineEditAPIKey->setObjectName(QString::fromUtf8("lineEditAPIKey"));
        lineEditAPIKey->setGeometry(QRect(100, 90, 121, 30));
        lineEditAPIKey->setFont(font);
        lineEditAPIKey->setEchoMode(QLineEdit::PasswordEchoOnEdit);
        lineEditAPIKey->setAlignment(Qt::AlignCenter);
        groupBoxAlarm = new QGroupBox(tab);
        groupBoxAlarm->setObjectName(QString::fromUtf8("groupBoxAlarm"));
        groupBoxAlarm->setGeometry(QRect(10, 330, 491, 171));
        groupBoxAlarm->setFont(font);
        lightPoint = new LightPoint(groupBoxAlarm);
        lightPoint->setObjectName(QString::fromUtf8("lightPoint"));
        lightPoint->setEnabled(false);
        lightPoint->setGeometry(QRect(370, 40, 111, 111));
        lightPoint->setAutoFillBackground(false);
        lightPoint->setStep(0);
        lightPoint->setInterval(100);
        lightPoint->setBgColor(QColor(0, 255, 0, 0));
        imageSwitchAlarm = new ImageSwitch(groupBoxAlarm);
        imageSwitchAlarm->setObjectName(QString::fromUtf8("imageSwitchAlarm"));
        imageSwitchAlarm->setGeometry(QRect(90, 0, 87, 28));
        imageSwitchAlarm->setButtonStyle(ImageSwitch::ButtonStyle_1);
        label_8 = new QLabel(groupBoxAlarm);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setGeometry(QRect(20, 40, 351, 41));
        label_8->setFont(font);
        label_8->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        xsliderWindSpeedLimit = new XSlider(groupBoxAlarm);
        xsliderWindSpeedLimit->setObjectName(QString::fromUtf8("xsliderWindSpeedLimit"));
        xsliderWindSpeedLimit->setGeometry(QRect(90, 40, 231, 36));
        xsliderWindSpeedLimit->setMinimumSize(QSize(0, 36));
        xsliderWindSpeedLimit->setFont(font);
        xsliderWindSpeedLimit->setMaximum(25);
        xsliderWindSpeedLimit->setPageStep(5);
        xsliderWindSpeedLimit->setValue(3);
        xsliderWindSpeedLimit->setSliderHeight(18);
        xsliderTemperatureLimit = new XSlider(groupBoxAlarm);
        xsliderTemperatureLimit->setObjectName(QString::fromUtf8("xsliderTemperatureLimit"));
        xsliderTemperatureLimit->setGeometry(QRect(90, 70, 231, 60));
        xsliderTemperatureLimit->setFont(font);
        xsliderTemperatureLimit->setMinimum(-20);
        xsliderTemperatureLimit->setMaximum(50);
        xsliderTemperatureLimit->setPageStep(5);
        xsliderTemperatureLimit->setValue(25);
        xsliderTemperatureLimit->setSliderHeight(18);
        label_9 = new QLabel(groupBoxAlarm);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setGeometry(QRect(20, 80, 341, 41));
        label_9->setFont(font);
        label_9->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        label_10 = new QLabel(groupBoxAlarm);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        label_10->setGeometry(QRect(20, 120, 351, 41));
        label_10->setFont(font);
        label_10->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        xsliderIlluminationLimit = new XSlider(groupBoxAlarm);
        xsliderIlluminationLimit->setObjectName(QString::fromUtf8("xsliderIlluminationLimit"));
        xsliderIlluminationLimit->setGeometry(QRect(90, 110, 231, 60));
        xsliderIlluminationLimit->setFont(font);
        xsliderIlluminationLimit->setMaximum(100);
        xsliderIlluminationLimit->setSingleStep(10);
        xsliderIlluminationLimit->setPageStep(100);
        xsliderIlluminationLimit->setValue(20);
        xsliderIlluminationLimit->setSliderHeight(18);
        label_9->raise();
        lightPoint->raise();
        imageSwitchAlarm->raise();
        label_8->raise();
        xsliderWindSpeedLimit->raise();
        xsliderTemperatureLimit->raise();
        label_10->raise();
        xsliderIlluminationLimit->raise();
        textEditLog = new QTextEdit(tab);
        textEditLog->setObjectName(QString::fromUtf8("textEditLog"));
        textEditLog->setGeometry(QRect(10, 520, 891, 141));
        textEditLog->setFont(font);
        pushButtonClearLog = new QPushButton(tab);
        pushButtonClearLog->setObjectName(QString::fromUtf8("pushButtonClearLog"));
        pushButtonClearLog->setGeometry(QRect(910, 520, 91, 141));
        pushButtonClearLog->setFont(font);
        tabWidget->addTab(tab, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QString::fromUtf8("tab_2"));
        waveChartTemperature = new WaveChart(tab_2);
        waveChartTemperature->setObjectName(QString::fromUtf8("waveChartTemperature"));
        waveChartTemperature->setGeometry(QRect(0, 30, 500, 300));
        waveChartTemperature->setFont(font);
        waveChartTemperature->setMinValue(0.000000000000000);
        waveChartTemperature->setMaxValue(40.000000000000000);
        waveChartTemperature->setYStep(20.000000000000000);
        waveChartTemperature->setSpace(40.000000000000000);
        waveChartTemperature->setSmoothType(0);
        waveChartTemperature->setShowPointBg(true);
        waveChartTemperature->setBgColorStart(QColor(255, 255, 255));
        waveChartTemperature->setBgColorEnd(QColor(255, 255, 255));
        waveChartTemperature->setTextColor(QColor(0, 0, 0));
        label_21 = new QLabel(tab_2);
        label_21->setObjectName(QString::fromUtf8("label_21"));
        label_21->setGeometry(QRect(220, 40, 91, 31));
        label_21->setTextFormat(Qt::PlainText);
        waveChartHumidity = new WaveChart(tab_2);
        waveChartHumidity->setObjectName(QString::fromUtf8("waveChartHumidity"));
        waveChartHumidity->setGeometry(QRect(510, 30, 500, 300));
        waveChartHumidity->setFont(font);
        waveChartHumidity->setMinValue(0.000000000000000);
        waveChartHumidity->setMaxValue(100.000000000000000);
        waveChartHumidity->setXStep(20.000000000000000);
        waveChartHumidity->setYStep(20.000000000000000);
        waveChartHumidity->setSpace(40.000000000000000);
        waveChartHumidity->setBgColorStart(QColor(255, 255, 255));
        waveChartHumidity->setBgColorEnd(QColor(255, 255, 255));
        waveChartHumidity->setTextColor(QColor(0, 0, 0));
        waveChartWindSpeed = new WaveChart(tab_2);
        waveChartWindSpeed->setObjectName(QString::fromUtf8("waveChartWindSpeed"));
        waveChartWindSpeed->setGeometry(QRect(0, 340, 500, 300));
        waveChartWindSpeed->setFont(font);
        waveChartWindSpeed->setMinValue(0.000000000000000);
        waveChartWindSpeed->setMaxValue(20.000000000000000);
        waveChartWindSpeed->setXStep(5.000000000000000);
        waveChartWindSpeed->setYStep(20.000000000000000);
        waveChartWindSpeed->setSpace(40.000000000000000);
        waveChartWindSpeed->setBgColorStart(QColor(255, 255, 255));
        waveChartWindSpeed->setBgColorEnd(QColor(255, 255, 255));
        waveChartWindSpeed->setTextColor(QColor(0, 0, 0));
        waveChartIllumination = new WaveChart(tab_2);
        waveChartIllumination->setObjectName(QString::fromUtf8("waveChartIllumination"));
        waveChartIllumination->setGeometry(QRect(510, 340, 500, 300));
        waveChartIllumination->setFont(font);
        waveChartIllumination->setMinValue(0.000000000000000);
        waveChartIllumination->setMaxValue(100.000000000000000);
        waveChartIllumination->setXStep(20.000000000000000);
        waveChartIllumination->setYStep(20.000000000000000);
        waveChartIllumination->setSpace(40.000000000000000);
        waveChartIllumination->setBgColorStart(QColor(255, 255, 255));
        waveChartIllumination->setBgColorEnd(QColor(255, 255, 255));
        waveChartIllumination->setTextColor(QColor(0, 0, 0));
        label_22 = new QLabel(tab_2);
        label_22->setObjectName(QString::fromUtf8("label_22"));
        label_22->setGeometry(QRect(730, 40, 91, 31));
        label_22->setTextFormat(Qt::PlainText);
        label_23 = new QLabel(tab_2);
        label_23->setObjectName(QString::fromUtf8("label_23"));
        label_23->setGeometry(QRect(210, 350, 91, 31));
        label_23->setTextFormat(Qt::PlainText);
        label_24 = new QLabel(tab_2);
        label_24->setObjectName(QString::fromUtf8("label_24"));
        label_24->setGeometry(QRect(730, 350, 111, 31));
        label_24->setTextFormat(Qt::PlainText);
        pushButtonClearCharts = new QPushButton(tab_2);
        pushButtonClearCharts->setObjectName(QString::fromUtf8("pushButtonClearCharts"));
        pushButtonClearCharts->setGeometry(QRect(860, 640, 141, 30));
        tabWidget->addTab(tab_2, QString());
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 1039, 26));
        menuFile = new QMenu(menubar);
        menuFile->setObjectName(QString::fromUtf8("menuFile"));
        menuAbout_2 = new QMenu(menubar);
        menuAbout_2->setObjectName(QString::fromUtf8("menuAbout_2"));
        menuData = new QMenu(menubar);
        menuData->setObjectName(QString::fromUtf8("menuData"));
        MainWindow->setMenuBar(menubar);

        menubar->addAction(menuFile->menuAction());
        menubar->addAction(menuData->menuAction());
        menubar->addAction(menuAbout_2->menuAction());
        menuFile->addSeparator();
        menuFile->addAction(menuReadINI);
        menuFile->addAction(menuWriteINI);
        menuFile->addSeparator();
        menuFile->addAction(menuExit);
        menuAbout_2->addAction(menuAbout);
        menuData->addAction(menuGetHardwareData);
        menuData->addAction(menuGetRandomData);
        menuData->addAction(menuGetInputData);

        retranslateUi(MainWindow);

        tabWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "\347\256\200\346\230\223\346\260\224\350\261\241\347\253\231V2.0-\351\207\221\351\231\265\347\247\221\346\212\200\345\255\246\351\231\242", nullptr));
        menuReadINI->setText(QCoreApplication::translate("MainWindow", "\350\257\273\345\217\226\351\205\215\347\275\256\346\226\207\344\273\266", nullptr));
#if QT_CONFIG(shortcut)
        menuReadINI->setShortcut(QCoreApplication::translate("MainWindow", "Ctrl+R", nullptr));
#endif // QT_CONFIG(shortcut)
        menuWriteINI->setText(QCoreApplication::translate("MainWindow", "\344\277\235\345\255\230\351\205\215\347\275\256\346\226\207\344\273\266", nullptr));
#if QT_CONFIG(shortcut)
        menuWriteINI->setShortcut(QCoreApplication::translate("MainWindow", "Ctrl+W", nullptr));
#endif // QT_CONFIG(shortcut)
        menuAbout->setText(QCoreApplication::translate("MainWindow", "\345\205\263\344\272\216", nullptr));
#if QT_CONFIG(shortcut)
        menuAbout->setShortcut(QCoreApplication::translate("MainWindow", "Ctrl+A", nullptr));
#endif // QT_CONFIG(shortcut)
        menuExit->setText(QCoreApplication::translate("MainWindow", "\351\200\200\345\207\272", nullptr));
#if QT_CONFIG(shortcut)
        menuExit->setShortcut(QCoreApplication::translate("MainWindow", "Ctrl+X", nullptr));
#endif // QT_CONFIG(shortcut)
        menuGetHardwareData->setText(QCoreApplication::translate("MainWindow", "\350\257\273\345\217\226\346\265\213\351\207\217\346\225\260\346\215\256", nullptr));
#if QT_CONFIG(tooltip)
        menuGetHardwareData->setToolTip(QCoreApplication::translate("MainWindow", "\350\257\273\345\217\226\346\265\213\351\207\217\346\225\260\346\215\256", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(shortcut)
        menuGetHardwareData->setShortcut(QCoreApplication::translate("MainWindow", "U", nullptr));
#endif // QT_CONFIG(shortcut)
        menuGetRandomData->setText(QCoreApplication::translate("MainWindow", "\347\224\237\346\210\220\346\250\241\346\213\237\346\225\260\346\215\256", nullptr));
#if QT_CONFIG(tooltip)
        menuGetRandomData->setToolTip(QCoreApplication::translate("MainWindow", "\347\224\237\346\210\220\346\250\241\346\213\237\346\225\260\346\215\256", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(shortcut)
        menuGetRandomData->setShortcut(QCoreApplication::translate("MainWindow", "S", nullptr));
#endif // QT_CONFIG(shortcut)
        menuGetInputData->setText(QCoreApplication::translate("MainWindow", "\350\276\223\345\205\245\346\250\241\346\213\237\346\225\260\346\215\256", nullptr));
#if QT_CONFIG(tooltip)
        menuGetInputData->setToolTip(QCoreApplication::translate("MainWindow", "\350\276\223\345\205\245\346\250\241\346\213\237\346\225\260\346\215\256", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(shortcut)
        menuGetInputData->setShortcut(QCoreApplication::translate("MainWindow", "T", nullptr));
#endif // QT_CONFIG(shortcut)
        groupBoxPorts->setTitle(QCoreApplication::translate("MainWindow", "\344\270\262\345\217\243\346\223\215\344\275\234", nullptr));
        label_6->setText(QCoreApplication::translate("MainWindow", "\346\260\224\350\261\241\344\277\241\346\201\257\344\270\262\345\217\243\357\274\232", nullptr));
        label_7->setText(QCoreApplication::translate("MainWindow", "\346\263\242\347\211\271\347\216\207\357\274\232           bps", nullptr));
        lineEditBaudRate1->setText(QCoreApplication::translate("MainWindow", "9600", nullptr));
        pushButtonOpenUart1->setText(QCoreApplication::translate("MainWindow", "\346\211\223\345\274\200\344\270\262\345\217\2431", nullptr));
        lineEditBaudRate2->setText(QCoreApplication::translate("MainWindow", "4800", nullptr));
        label_11->setText(QCoreApplication::translate("MainWindow", "\346\263\242\347\211\271\347\216\207\357\274\232           bps", nullptr));
        label_12->setText(QCoreApplication::translate("MainWindow", "\351\243\216\351\200\237\351\243\216\345\220\221\344\270\262\345\217\243\357\274\232", nullptr));
        pushButtonOpenUart2->setText(QCoreApplication::translate("MainWindow", "\346\211\223\345\274\200\344\270\262\345\217\2432", nullptr));
        groupBox_4->setTitle(QCoreApplication::translate("MainWindow", "\345\267\245\344\275\234\346\250\241\345\274\217", nullptr));
        radioButtonManualMode->setText(QCoreApplication::translate("MainWindow", "\346\211\213\345\212\250\351\207\207\351\233\206\346\250\241\345\274\217", nullptr));
        radioButtonAutoMode->setText(QCoreApplication::translate("MainWindow", "\350\207\252\345\212\250\351\207\207\351\233\206\346\250\241\345\274\217", nullptr));
        pushButtonGetHardwareData->setText(QCoreApplication::translate("MainWindow", "\350\257\273\345\217\226\346\265\213\351\207\217\346\225\260\346\215\256", nullptr));
        pushButtonGetRandomData->setText(QCoreApplication::translate("MainWindow", "\347\224\237\346\210\220\346\250\241\346\213\237\346\225\260\346\215\256", nullptr));
        pushButtonGetInputData->setText(QCoreApplication::translate("MainWindow", "\350\276\223\345\205\245\346\250\241\346\213\237\346\225\260\346\215\256", nullptr));
        groupBoxWeatherInfo->setTitle(QCoreApplication::translate("MainWindow", "\346\260\224\350\261\241\344\277\241\346\201\257", nullptr));
        label_5->setText(QCoreApplication::translate("MainWindow", "\351\243\216\345\220\221", nullptr));
        gaugeSimpleHumidity->setTitle(QString());
        gaugeSimpleTemperature->setTitle(QString());
        gaugeSimpleWindSpeed->setTitle(QString());
        label->setText(QCoreApplication::translate("MainWindow", "\346\271\277\345\272\246 %RH", nullptr));
        label_2->setText(QCoreApplication::translate("MainWindow", "\346\270\251\345\272\246 \342\204\203", nullptr));
        label_3->setText(QCoreApplication::translate("MainWindow", "\351\243\216\351\200\237 m/s", nullptr));
        navLabel->setText(QCoreApplication::translate("MainWindow", "\346\260\224\345\216\213(kPa):", nullptr));
        navLabelPressure->setText(QCoreApplication::translate("MainWindow", "101.325", nullptr));
        navLabel_2->setText(QCoreApplication::translate("MainWindow", "\347\205\247\345\272\246(lux):", nullptr));
        navLabelIllumination->setText(QCoreApplication::translate("MainWindow", "1000", nullptr));
        navLabelAltitude->setText(QCoreApplication::translate("MainWindow", "25", nullptr));
        navLabel_3->setText(QCoreApplication::translate("MainWindow", "\346\265\267\346\213\224(m):", nullptr));
        groupBoxTCP->setTitle(QCoreApplication::translate("MainWindow", "TCP\351\200\232\344\277\241", nullptr));
        lineEditScriptName->setText(QString());
        label_18->setText(QCoreApplication::translate("MainWindow", "\350\204\232\346\234\254\345\220\215\347\247\260\357\274\232", nullptr));
        lineEditAuthCode->setText(QString());
        lineEditProductID->setText(QString());
        label_16->setText(QCoreApplication::translate("MainWindow", "\344\272\247\345\223\201ID\357\274\232", nullptr));
        label_17->setText(QCoreApplication::translate("MainWindow", "\351\211\264\346\235\203\347\240\201\357\274\232", nullptr));
        groupBoxHTTP->setTitle(QCoreApplication::translate("MainWindow", "HTTP\351\200\232\344\277\241", nullptr));
        label_14->setText(QCoreApplication::translate("MainWindow", "\350\256\276\345\244\207ID\357\274\232", nullptr));
        label_15->setText(QCoreApplication::translate("MainWindow", "API-KEY\357\274\232", nullptr));
        lineEditDeviceID->setText(QString());
        lineEditAPIKey->setInputMask(QString());
        lineEditAPIKey->setText(QString());
        groupBoxAlarm->setTitle(QCoreApplication::translate("MainWindow", "\346\212\245\350\255\246\345\212\237\350\203\275", nullptr));
        label_8->setText(QCoreApplication::translate("MainWindow", "\351\243\216\351\200\237\344\270\212\351\231\220                                m/s", nullptr));
        label_9->setText(QCoreApplication::translate("MainWindow", "\346\270\251\345\272\246\344\270\212\351\231\220                                \342\204\203", nullptr));
        label_10->setText(QCoreApplication::translate("MainWindow", "\347\205\247\345\272\246\344\270\212\351\231\220                                kLux", nullptr));
        pushButtonClearLog->setText(QCoreApplication::translate("MainWindow", "\346\270\205\347\251\272", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab), QCoreApplication::translate("MainWindow", "\345\256\236\346\227\266\346\225\260\346\215\256", nullptr));
        waveChartTemperature->setTitle(QString());
        label_21->setText(QCoreApplication::translate("MainWindow", "\346\270\251\345\272\246\357\274\210\342\204\203\357\274\211", nullptr));
        waveChartHumidity->setTitle(QString());
        waveChartWindSpeed->setTitle(QString());
        waveChartIllumination->setTitle(QString());
        label_22->setText(QCoreApplication::translate("MainWindow", "\346\271\277\345\272\246\357\274\210%RH\357\274\211", nullptr));
        label_23->setText(QCoreApplication::translate("MainWindow", "\351\243\216\351\200\237(m/s\357\274\211", nullptr));
        label_24->setText(QCoreApplication::translate("MainWindow", "\347\205\247\345\272\246\357\274\210klux\357\274\211", nullptr));
        pushButtonClearCharts->setText(QCoreApplication::translate("MainWindow", "\346\270\205\347\251\272\346\211\200\346\234\211\346\233\262\347\272\277", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QCoreApplication::translate("MainWindow", "\345\216\206\345\217\262\346\225\260\346\215\256", nullptr));
        menuFile->setTitle(QCoreApplication::translate("MainWindow", "\346\226\207\344\273\266(&F)", nullptr));
        menuAbout_2->setTitle(QCoreApplication::translate("MainWindow", "\345\205\263\344\272\216(&A)", nullptr));
        menuData->setTitle(QCoreApplication::translate("MainWindow", "\346\225\260\346\215\256(&D)", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
