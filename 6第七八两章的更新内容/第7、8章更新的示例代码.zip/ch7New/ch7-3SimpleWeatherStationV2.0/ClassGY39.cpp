﻿#include "ClassGY39.h"

int ClassGY39::getIllumination()
{
    return m_nIllumination;
}

int ClassGY39::setIllumination(int nIllumi)
{
    m_nIllumination = nIllumi;
    return 0;
}

float ClassGY39::getTemperature()
{
    return m_fTemperature;
}

int ClassGY39::setTemperature(float fTemp)
{
    m_fTemperature = fTemp;
    return 0;
}

float ClassGY39::getPressure()
{
    return m_fPressure;
}

int ClassGY39::setPressure(float fPres)
{
    m_fPressure = fPres;
    return 0;
}

int ClassGY39::getHumidity()
{
    return m_nHumidity;
}

int ClassGY39::setHumidity(int nHumi)
{
    m_nHumidity = nHumi;
    return 0;
}

int ClassGY39::getAltitude()
{
    return m_nAltitude;
}

int ClassGY39::setAltitude(int nAlti)
{
    m_nAltitude = nAlti;
    return 0;
}

int ClassGY39::readSerialData(QSerialPort *serialPort)
{
    QByteArray qbaWeatherData = serialPort->readAll();

    if (qbaWeatherData.length() % 24 != 0 || qbaWeatherData.length() == 0) //检查数据长度
    {
        return -1; //数据长度不正确
    }

    qbaWeatherData = qbaWeatherData.right(24); //取最后一组数据

    if (verifySerialData(qbaWeatherData) != 0)
    {
        return -2; //数据校验错误
    }

    parseSerialData(qbaWeatherData);
    return 0;
}

int ClassGY39::parseSerialData(QByteArray qbaSerialData)
{
    unsigned char *cData = (unsigned char *)qbaSerialData.data();
    int nIllumi = (cData[4] << 24) + (cData[5] << 16) + (cData[6] << 8) + cData[7];
    float fTemp = ((qbaSerialData[13] << 8) + cData[14]) / 100.0;
    float fPre = ((cData[15] << 24) + (cData[16] << 16) + (cData[17] << 8) + cData[18]) / 100.0 / 1000.0;
    int nHum = ((cData[19] << 8) + cData[20]) / 100.0;
    int nAlti = (qbaSerialData[21] << 8) + cData[22];

    int flag = 0;
    flag += setIllumination(nIllumi);
    flag += setTemperature(fTemp);
    flag += setPressure(fPre);
    flag += setHumidity(nHum);
    flag += setAltitude(nAlti);

    return flag;
}

int ClassGY39::verifySerialData(QByteArray qbaSerialData)
{
    unsigned int nSum = 0;

    //校验光照强度数据包
    foreach (char cTmp, qbaSerialData.left(8)) //累加求和
    {
        nSum += cTmp;
    }
    //判断求和结果和校验位是否相同
    if ((nSum % 256) != (unsigned char)qbaSerialData.at(8))
    {
        return -1; //不相同返回-1
    }

    //校验温度湿度数据包
    nSum = 0;
    foreach (char cTmp, qbaSerialData.right(15).left(14))
    {
        nSum += cTmp;
    }

    if ((nSum % 256) != (unsigned char)qbaSerialData.at(23))
    {
        return -2; //不相同返回-2
    }
    return 0;
}

QByteArray ClassGY39::dataToHex()
{
    QByteArray qbaHexData;
    qbaHexData.append(QString("%1").arg(getHumidity(), 3));
    qbaHexData.append(QString("%1").arg(getTemperature(), 6));
    qbaHexData.append(QString("%1").arg(getAltitude(), 4));
    qbaHexData.append(QString("%1").arg(getPressure(), 7));
    qbaHexData.append(QString("%1").arg(getIllumination(), 6));
    return qbaHexData;
}
