﻿#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->gaugeArc->setValue(100);
    ui->gaugeCompassPan->setValue(180);
}

MainWindow::~MainWindow()
{
    delete ui;
}
