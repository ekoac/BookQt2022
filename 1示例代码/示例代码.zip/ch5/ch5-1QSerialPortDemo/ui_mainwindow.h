/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QComboBox *comboBoxPortList;
    QPushButton *pushButtonGetPortList;
    QPushButton *pushButtonOpenPort;
    QPushButton *pushButtonWriteData;
    QPushButton *pushButtonReadData;
    QPushButton *pushButtonClosePort;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(461, 118);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        comboBoxPortList = new QComboBox(centralwidget);
        comboBoxPortList->setObjectName(QString::fromUtf8("comboBoxPortList"));
        comboBoxPortList->setGeometry(QRect(130, 20, 311, 30));
        pushButtonGetPortList = new QPushButton(centralwidget);
        pushButtonGetPortList->setObjectName(QString::fromUtf8("pushButtonGetPortList"));
        pushButtonGetPortList->setGeometry(QRect(20, 20, 93, 30));
        pushButtonOpenPort = new QPushButton(centralwidget);
        pushButtonOpenPort->setObjectName(QString::fromUtf8("pushButtonOpenPort"));
        pushButtonOpenPort->setGeometry(QRect(20, 70, 93, 30));
        pushButtonWriteData = new QPushButton(centralwidget);
        pushButtonWriteData->setObjectName(QString::fromUtf8("pushButtonWriteData"));
        pushButtonWriteData->setGeometry(QRect(240, 70, 93, 30));
        pushButtonReadData = new QPushButton(centralwidget);
        pushButtonReadData->setObjectName(QString::fromUtf8("pushButtonReadData"));
        pushButtonReadData->setGeometry(QRect(350, 70, 93, 30));
        pushButtonClosePort = new QPushButton(centralwidget);
        pushButtonClosePort->setObjectName(QString::fromUtf8("pushButtonClosePort"));
        pushButtonClosePort->setGeometry(QRect(130, 70, 93, 30));
        MainWindow->setCentralWidget(centralwidget);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        pushButtonGetPortList->setText(QCoreApplication::translate("MainWindow", "\350\216\267\345\217\226\344\270\262\345\217\243", nullptr));
        pushButtonOpenPort->setText(QCoreApplication::translate("MainWindow", "\346\211\223\345\274\200\344\270\262\345\217\243", nullptr));
        pushButtonWriteData->setText(QCoreApplication::translate("MainWindow", "\345\206\231\346\225\260\346\215\256", nullptr));
        pushButtonReadData->setText(QCoreApplication::translate("MainWindow", "\350\257\273\346\225\260\346\215\256", nullptr));
        pushButtonClosePort->setText(QCoreApplication::translate("MainWindow", "\345\205\263\351\227\255\344\270\262\345\217\243", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
