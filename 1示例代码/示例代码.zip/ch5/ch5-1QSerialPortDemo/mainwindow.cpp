﻿#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QSerialPort>
#include <QSerialPortInfo>
#include <QDebug>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButtonGetPortList_clicked()
{
    foreach (QSerialPortInfo info, QSerialPortInfo::availablePorts())
    {
        ui->comboBoxPortList->addItem(info.portName());
    }
}

void MainWindow::on_pushButtonOpenPort_clicked()
{
    //（2）设置串口的工作参数
    m_port->setPortName(ui->comboBoxPortList->currentText()); //选取串口
    m_port->setBaudRate(QSerialPort::Baud9600);               //设置波特率
    m_port->setDataBits(QSerialPort::Data8);                  //设置数据位数
    m_port->setParity(QSerialPort::NoParity);                 //设置奇校验类型
    m_port->setStopBits(QSerialPort::OneStop);                //设置停止位长度
    m_port->setFlowControl(QSerialPort::NoFlowControl);       //设置流控制

    //（3）打开串口
    m_port->open(QIODevice::ReadWrite);

    //（4）判断串口是否已打开
    if (m_port->isOpen())
    {
        qDebug() << "打开串口成功";
    }
    else
    {
        qDebug() << "打开串口失败";
    }
}

void MainWindow::on_pushButtonWriteData_clicked()
{
    QByteArray data = "This is a test.";
    qDebug() << m_port->write(data);
}

void MainWindow::on_pushButtonReadData_clicked()
{
    qDebug() << m_port->readAll();
}

void MainWindow::on_pushButtonClosePort_clicked()
{
    m_port->close();
}
