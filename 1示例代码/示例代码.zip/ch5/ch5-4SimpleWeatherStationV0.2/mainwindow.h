﻿#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "ClassGY39.h"
#include "ClassPR3000.h"


QT_BEGIN_NAMESPACE
namespace Ui
{
    class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

private:
    Ui::MainWindow *ui;

    ClassGY39 *m_GY39Device;
    ClassPR3000 *m_PR3000Device;

    QSerialPort *m_serialWeather;
    QSerialPort *m_serialWind;

    int m_nSerialWeatherOpenedFlag;
    int m_nSerialWindOpenedFlag;

    void printLog(QString log1, QString log2 = "");

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    void updateSerialInfo();
    void alarm();
    void updateUI();

private slots:
    void on_pushButtonGetRandomData_clicked();
    void on_pushButtonGetHardwareData_clicked();
    void on_pushButtonClearLog_clicked();
    void on_pushButtonOpenUart1_clicked();
    void on_pushButtonOpenUart2_clicked();
    void on_pushButtonClearCharts_clicked();

    void on_menuExit_triggered();
    void on_menuAbout_triggered();
    void on_menuGetHardwareData_triggered();
    void on_menuGetRandomData_triggered();
};
#endif // MAINWINDOW_H
