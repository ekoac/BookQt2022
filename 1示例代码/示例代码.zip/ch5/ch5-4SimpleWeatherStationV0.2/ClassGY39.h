﻿#ifndef CLASS_GY39DATA_H
#define CLASS_GY39DATA_H

#include <QSerialPort>

class ClassGY39
{
private:
    int m_nIllumination = 0;  // 照度，0~200000lux
    float m_fTemperature = 0; // 温度，-20~45℃
    float m_fPressure = 0;    // 气压，90~110kPa
    int m_nHumidity = 0;      // 湿度，0~100%RH
    int m_nAltitude = 0;      // 海拔，-200~9000m

    int parseSerialData(QByteArray qbaSerialData);
    int verifySerialData(QByteArray qbaSerialData);

public:
    int getIllumination();
    int setIllumination(int nIllumi);

    float getTemperature();
    int setTemperature(float fTemp);

    float getPressure();
    int setPressure(float fPres);

    int getHumidity();
    int setHumidity(int nHumi);

    int getAltitude();
    int setAltitude(int nAlti);

    int readSerialData(QSerialPort *serialPort); //从串口读取气象数据
};
#endif // CLASS_GY39DATA_H
