﻿#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "ClassGY39.h"
#include "ClassPR3000.h"
#include <QRandomGenerator>
#include <QDateTime>
#include <QSerialPort>
#include <QSerialPortInfo>
#include <QDebug>
#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent), ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    m_GY39Device = new ClassGY39();
    m_PR3000Device = new ClassPR3000();
    m_nSerialWeatherOpenedFlag = 0;
    m_nSerialWindOpenedFlag = 0;

    m_serialWeather = new QSerialPort(); //气象信息串口
    m_serialWind = new QSerialPort();    //风速信息串口

    ui->tabWidget->setCurrentIndex(1);

    updateSerialInfo();
}

MainWindow::~MainWindow()
{
    delete m_serialWeather; //气象信息串口
    delete m_serialWind;    //风速信息串口
    delete m_GY39Device;
    delete m_PR3000Device;
    delete ui;
}

void MainWindow::updateSerialInfo()
{
    ui->comboBoxUart1->clear();
    ui->comboBoxUart2->clear();

    printLog("检测到串口信息：");
    foreach (const QSerialPortInfo &info, QSerialPortInfo::availablePorts())
    {
        ui->comboBoxUart1->addItem(info.portName());
        ui->comboBoxUart2->addItem(info.portName());
        printLog(info.portName(), info.description());
    }

    ui->comboBoxUart1->model()->sort(0);
    ui->comboBoxUart2->model()->sort(0);
}

void MainWindow::on_pushButtonGetRandomData_clicked()
{
    int nSeed = QDateTime::currentDateTime().toSecsSinceEpoch();
    QRandomGenerator generator(nSeed);

    m_GY39Device->setIllumination(generator.bounded(0, 200000));
    m_GY39Device->setTemperature(generator.bounded(-20, 45));
    m_GY39Device->setPressure(generator.bounded(90000, 110000)/1000.0);
    m_GY39Device->setHumidity(generator.bounded(0, 100));
    m_GY39Device->setAltitude(generator.bounded(-200, 9000));

    m_PR3000Device->setWindSpeed(generator.bounded(0, 20));
    m_PR3000Device->setWindDirection(generator.bounded(0, 359));

    printLog("生成模拟数据", QString("温度%1℃，湿度%2%RH，海拔%3m，气压%4kPa，照度%5lux，风速%6m/s，风向%7°")
                                 .arg(m_GY39Device->getTemperature())
                                 .arg(m_GY39Device->getHumidity())
                                 .arg(m_GY39Device->getAltitude())
                                 .arg(m_GY39Device->getPressure())
                                 .arg(m_GY39Device->getIllumination())
                                 .arg(m_PR3000Device->getWindSpeed())
                                 .arg(m_PR3000Device->getWindDirection()));
    updateUI();
    if (ui->imageSwitchAlarm->getChecked())
    {
        alarm();
    }
}

void MainWindow::on_pushButtonOpenUart1_clicked()
{
    if (m_nSerialWeatherOpenedFlag == 0) //判断当前串口的状态
    {
        //初始化气象信息串口
        m_serialWeather->setPortName(ui->comboBoxUart1->currentText());      //选取串口
        m_serialWeather->setBaudRate(ui->lineEditBaudRate1->text().toInt()); //波特率
        m_serialWeather->setDataBits(QSerialPort::Data8);                    //数据位数
        m_serialWeather->setParity(QSerialPort::NoParity);                   //奇偶校验类型
        m_serialWeather->setStopBits(QSerialPort::OneStop);                  //停止位数
        m_serialWeather->setFlowControl(QSerialPort::NoFlowControl);         //流控制
        m_serialWeather->open(QIODevice::ReadWrite);                         //打开串口

        if (m_serialWeather->isOpen())
        {
            printLog("串口1已打开", ui->comboBoxUart1->currentText());
            ui->pushButtonOpenUart1->setText("关闭串口1");
            m_nSerialWeatherOpenedFlag = 1;
        }
        else
        {
            printLog("串口1打开失败");
        }
    }
    else
    {
        printLog("串口1已关闭");
        ui->pushButtonOpenUart1->setText("打开串口1");
        m_nSerialWeatherOpenedFlag = 0;
        m_serialWeather->close();
    }
}

void MainWindow::on_pushButtonOpenUart2_clicked()
{
    if (m_nSerialWindOpenedFlag == 0) //判断当前串口的状态
    {
        //初始化风速信息串口
        m_serialWind->setPortName(ui->comboBoxUart2->currentText());      //选取串口
        m_serialWind->setBaudRate(ui->lineEditBaudRate2->text().toInt()); //波特率
        m_serialWind->setDataBits(QSerialPort::Data8);                    //数据位数
        m_serialWind->setParity(QSerialPort::NoParity);                   //奇偶校验类型
        m_serialWind->setStopBits(QSerialPort::OneStop);                  //停止位
        m_serialWind->setFlowControl(QSerialPort::NoFlowControl);         //流控制
        m_serialWind->open(QIODevice::ReadWrite);                         //打开串口

        if (m_serialWind->isOpen())
        {
            printLog("串口2已打开", ui->comboBoxUart2->currentText());
            ui->pushButtonOpenUart2->setText("关闭串口2");
            m_nSerialWindOpenedFlag = 1;
        }
        else
        {
            printLog("串口2打开失败");
        }
    }
    else
    {
        ui->pushButtonOpenUart2->setText("打开串口2");
        printLog("串口2已关闭", "");
        m_nSerialWindOpenedFlag = 0;
        m_serialWind->close();
    }
}

void MainWindow::on_pushButtonGetHardwareData_clicked()
{
    int nGY39DataValidFlag = -1, nPR3000DataValidFlag = -1;
    if (m_nSerialWeatherOpenedFlag == 1)
    {
        nGY39DataValidFlag = m_GY39Device->readSerialData(m_serialWeather);
        switch (nGY39DataValidFlag)
        {
        case -1:
            printLog("串口1数据长度不正确");
            break;
        case -2:
            printLog("串口1数据校验错误");
            break;
        }
    }

    if (m_nSerialWindOpenedFlag == 1)
    {
        nPR3000DataValidFlag = m_PR3000Device->readSerialData(m_serialWind);

        switch (nPR3000DataValidFlag)
        {
        case -1:
            printLog("串口2风速数据校验错误");
            break;
        case -2:
            printLog("串口2风向数据校验错误");
            break;
        }
    }

    if ((nGY39DataValidFlag == 0) || (nPR3000DataValidFlag == 0))
    {
        printLog("读取硬件数据", QString("温度%1℃，湿度%2%RH，海拔%3m，气压%4kPa，照度%5lux，风速%6m/s，风向%7°")
                                     .arg(m_GY39Device->getTemperature())
                                     .arg(m_GY39Device->getHumidity())
                                     .arg(m_GY39Device->getAltitude())
                                     .arg(m_GY39Device->getPressure())
                                     .arg(m_GY39Device->getIllumination())
                                     .arg(m_PR3000Device->getWindSpeed())
                                     .arg(m_PR3000Device->getWindDirection()));
        updateUI();
        if (ui->imageSwitchAlarm->getChecked())
        {
            alarm();
        }
    }
}

void MainWindow::printLog(QString log1, QString log2)
{
    QString time = QDateTime::currentDateTime().time().toString();     //获取当前时间
    QString log = QString("%1  %2  %3").arg(time).arg(log1).arg(log2); //生成日志内容
    ui->textEditLog->append(log);                                      //输出日志
}

void MainWindow::alarm()
{
    int nAlarmFlag = 0; //标志位，不为零则需要报警
    QByteArray qbaLogText;

    if (m_GY39Device->getTemperature() > ui->xsliderTemperatureLimit->value())
    {
        nAlarmFlag = 1;
        qbaLogText.append("温度 ");
    }
    if (m_GY39Device->getIllumination() > ui->xsliderIlluminationLimit->value() * 1000)
    {
        nAlarmFlag = 1;
        qbaLogText.append("照度 ");
    }
    if (m_PR3000Device->getWindSpeed() > ui->xsliderWindSpeedLimit->value())
    {
        nAlarmFlag = 1;
        qbaLogText.append("风速 ");
    }

    if (nAlarmFlag == 1)
    {
        ui->lightPoint->setBgColor(QColor(255, 0, 0)); //指示灯设为红色
        ui->lightPoint->setStep(10);                   //指示灯闪烁
        printLog(qbaLogText, "超过限值，正在报警");
    }
    else
    {
        ui->lightPoint->setBgColor(QColor(0, 255, 0)); //指示灯设为绿色
        ui->lightPoint->setStep(0);                    //指示灯停止闪烁
    }
}

void MainWindow::updateUI()
{
    ui->gaugeSimpleHumidity->setValue(m_GY39Device->getHumidity());                 //湿度
    ui->gaugeSimpleTemperature->setValue(m_GY39Device->getTemperature());      //温度
    ui->gaugeSimpleWindSpeed->setValue(m_PR3000Device->getWindSpeed());             //风速
    ui->gaugeCompassPanWindDirection->setValue(m_PR3000Device->getWindDirection()); //风向

    ui->navLabelPressure->setText(QString::number(m_GY39Device->getPressure(), 'f', 3)); //气压
    ui->navLabelIllumination->setText(QString::number(m_GY39Device->getIllumination())); //照度
    ui->navLabelAltitude->setText(QString::number(m_GY39Device->getAltitude()));         //海拔

    ui->waveChartTemperature->addData(m_GY39Device->getTemperature());
    ui->waveChartHumidity->addData(m_GY39Device->getHumidity());
    ui->waveChartIllumination->addData(m_GY39Device->getIllumination() / 1000);
    ui->waveChartWindSpeed->addData(m_PR3000Device->getWindSpeed());
}

void MainWindow::on_pushButtonClearLog_clicked()
{
    ui->textEditLog->clear();
}

void MainWindow::on_menuExit_triggered()
{
    this->close();
}

void MainWindow::on_menuAbout_triggered()
{
    QMessageBox::information(this,
                             "关于",
                             "简易气象站V0.2\r\n——金陵科技学院电子信息工程学院");

}

void MainWindow::on_menuGetHardwareData_triggered()
{
    on_pushButtonGetHardwareData_clicked();
}

void MainWindow::on_menuGetRandomData_triggered()
{
    on_pushButtonGetRandomData_clicked();
}

void MainWindow::on_pushButtonClearCharts_clicked()
{
    ui->waveChartTemperature->clearData();
    ui->waveChartHumidity->clearData();
    ui->waveChartIllumination->clearData();
    ui->waveChartWindSpeed->clearData();
}
