﻿#ifndef CLASS_PR3000_H
#define CLASS_PR3000_H

#include <QByteArray>
#include <QSerialPort>

class ClassPR3000 : public QObject
{
private:
    float m_fWindSpeed = 0;   // 风速，0~20m/s
    int m_nWindDirection = 0; // 风向，0~359度（从正北开始，顺时针计算）

    QByteArray m_qbaRequestWS = QByteArray::fromHex("010300000001840A");     //风速问讯帧
    QByteArray m_qbaRequestWD = QByteArray::fromHex("020300000002C438"); //风向问讯帧

public:
    float getWindSpeed(); //接口函数
    int setWindSpeed(float fWS);

    int getWindDirection();
    int setWindDirection(int nWD);

    int readSerialData(QSerialPort *serialPort);                             //从串口读取风速风向数据
    int crc16Verify(const QByteArray qbaData, const QByteArray qbaCheckSum); //对风速风向数据进行CRC16校验
};

#endif // CLASS_PR3000_H
