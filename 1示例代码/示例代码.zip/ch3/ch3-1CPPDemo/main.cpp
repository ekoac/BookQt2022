﻿// 示例代码\ch3\ch3-1CPPDemo\main.cpp    // C++风格的注释

#include <iostream> // 预处理内容

namespace mySpace // 名称空间mySpace
{
    int nNum = 321; // 属于mySpace的变量
}

using namespace std; // 后续代码使用的默认名称空间为std
int nNum = 0;        // 在默认名称空间std中声明了全局变量nNum

int main() // 主函数
{
    char cStr[] = "Please enter a number:";                        // 定义了字符串并初始化
    cout << "Hello!" << endl<< cStr;                               // 输出字符串内容
    cin >> nNum;                                                   // 读取用户输入
    cout << "The number you entered is: " << nNum << endl;         // 输出变量
    cout << "The number in myspace is: " << mySpace::nNum << endl; // 输出名称空间std中的变量
    return 0;                                                      // 程序结束
}
