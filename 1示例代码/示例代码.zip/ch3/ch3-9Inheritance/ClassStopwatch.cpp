#include "ClassStopwatch.h"

void ClassStopwatch::startTiming()
{
    m_nRunningFlag = 1;
}

void ClassStopwatch::stopTiming()
{
    m_nRunningFlag = 0;
}

void ClassStopwatch::clear()
{
    m_nTiming = 0;
}