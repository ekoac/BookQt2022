﻿#include <iostream>
#include "ClassStopwatch.h" //引用头文件

using namespace std;

int ClassClock::ms_nCount = 0; //初始化基类的静态成员变量

int main()
{
    ClassStopwatch myWatch;                                      //定义派生类对象
    myWatch.setTime(12, 0, 0);                                   //调用基类的公有成员函数
    myWatch.startTiming();                                       //调用派生类的公有成员函数
    ClassClock::ms_nCount = 2;                                   //通过基类名访问基类静态成员变量
    cout << "myWatch.ms_nCount:" << myWatch.ms_nCount << endl;   //访问基类静态成员变量
    ClassStopwatch::ms_nCount = 5;                               //通过派生类名访问基类静态成员变量
    cout << "myWatch.getCount():" << myWatch.getCount() << endl; //访问基类静态成员函数
    return 0;
}
