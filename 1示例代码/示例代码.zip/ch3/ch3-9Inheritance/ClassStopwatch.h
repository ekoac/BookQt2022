#include "ClassClock.h"

class ClassStopwatch : public ClassClock
{
private:
    int m_nTiming;      //计时时间
    int m_nRunningFlag; //秒表运行状态

public:
    void startTiming(); //开始计时
    void stopTiming();  //停止计时
    void clear();       //归零
};
