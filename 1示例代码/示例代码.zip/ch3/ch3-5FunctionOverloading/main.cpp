﻿#include <iostream>

using namespace std;

int max(int nArg1, int nArg2) // int型
{
    return nArg1 > nArg2 ? nArg1 : nArg2;
}

float max(float fArg1, float fArg2) // float型
{
    return fArg1 > fArg2 ? fArg1 : fArg2;
}

char max(char cArg1, char cArg2) // char型
{
    return cArg1 > cArg2 ? cArg1 : cArg2;
}

int main()
{
    int n1 = 3, n2 = 4;
    cout << "Max of n1 and n2 is: " << max(n1, n2) << endl;

    float f1 = 2.72, f2 = 3.14;
    cout << "Max of f1 and f2 is: " << max(f1, f2) << endl;

    char c1 = 'A', c2 = 'B';
    cout << "Max of c1 and c2 is: " << max(c1, c2) << endl;

    return 0;
}
