﻿#include <iostream>
#include "ClassClock.h" //引用类定义

using namespace std;

int main()
{
    ClassClock myClock; //定义类对象
    int h, m, s;

    myClock.setTime(12, 34, 56);   //调用公有成员函数
    myClock.m_nHourAlarm = 3;      //直接访问公有成员变量
    myClock.m_nMinuteAlarm = 30;   //直接访问公有成员变量
    // myClock.nHour = 1;          //访问私有成员变量，会引发错误！！！
    myClock.getTime(&h, &m, &s);   //调用公有成员函数
    cout << "Current time is " << h << ":" << m << ":" << s << endl;
    cout << "Alarm time is " << myClock.m_nHourAlarm << ":" << myClock.m_nMinuteAlarm << endl;

    return 0;
}
