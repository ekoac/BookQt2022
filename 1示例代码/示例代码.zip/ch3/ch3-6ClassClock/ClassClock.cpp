﻿#include "ClassClock.h"

void ClassClock::setTime(int h, int m, int s)
{
    m_nHour = h;
    m_nMinute = m;
    m_nSecond = s;
}

void ClassClock::setAlarm(int h, int m)
{
    m_nHourAlarm = h;
    m_nMinuteAlarm = m;
}

void ClassClock::getTime(int *h, int *m, int *s)
{
    *h = m_nHour;
    *m = m_nMinute;
    *s = m_nSecond;
}

void ClassClock::getAlarm(int *h, int *m)
{
    *h = m_nHourAlarm;
    *m = m_nMinuteAlarm;
}
