﻿#include "ClassClock.h"

void ClassClock::setTime(int h, int m, int s)
{
    m_nHour = h;
    m_nMinute = m;
    m_nSecond = s;
}

void ClassClock::setAlarm(int h, int m)
{
    m_nHourAlarm = h;
    m_nMinuteAlarm = m;
}

void ClassClock::getTime(int *h, int *m, int *s)
{
    *h = m_nHour;
    *m = m_nMinute;
    *s = m_nSecond;
}

void ClassClock::getAlarm(int *h, int *m)
{
    *h = m_nHourAlarm;
    *m = m_nMinuteAlarm;
}

ClassClock::ClassClock()
{
    m_nHour = 0;
    m_nMinute = 0;
    m_nSecond = 0;
    m_nHourAlarm = 0;
    m_nMinuteAlarm = 0;
}

ClassClock::ClassClock(int h, int m, int s, int ha, int ma)
{
    m_nHour = h;
    m_nMinute = m;
    m_nSecond = s;
    m_nHourAlarm = ha;
    m_nMinuteAlarm = ma;
}

ClassClock::~ClassClock()
{
}

int ClassClock::getCount()
{
    return ms_nCount;
}
