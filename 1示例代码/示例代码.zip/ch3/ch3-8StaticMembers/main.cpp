﻿#include <iostream>
#include "ClassClock.h"

using namespace std;

int ClassClock::ms_nCount = 0;

int main()
{
    ClassClock clock1, clock2;
    clock1.ms_nCount = 11;                                              //通过类对象访问
    cout << "clock1.ms_nCount: " << clock1.ms_nCount << endl;           //通过类对象访问
    cout << "clock2.getCount(): " << clock1.getCount() << endl;         //通过静态成员函数访问
    ClassClock::ms_nCount = 22;                                         //通过类名访问
    cout << "ClassClock::ms_nCount: " << ClassClock::ms_nCount << endl; //通过类名访问

    return 0;
}
