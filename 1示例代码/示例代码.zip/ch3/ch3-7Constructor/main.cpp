﻿#include <iostream>
#include "ClassClock.h"

using namespace std;

int main()
{
    ClassClock clock1;                 // 调用不带参数的构造函数
    ClassClock clock2(0, 0, 0, 3, 30); // 调用带参数的构造函数

    return 0;
}
