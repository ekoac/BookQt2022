// ClassClock.h
class ClassClock
{
private:
    int m_nHour;   //当前时间的小时部分
    int m_nMinute; //当前时间的分钟部分
    int m_nSecond; //当前时间的秒部分

public:
    int m_nHourAlarm;   //闹钟时间的小时部分
    int m_nMinuteAlarm; //闹钟时间的分钟部分

    void setTime(int h, int m, int s);    //设置时间
    void setAlarm(int h, int m);          //设置闹钟时间
    void getTime(int *h, int *m, int *s); //读取时间
    void getAlarm(int *h, int *m);        //读取闹钟时间

    ClassClock();                                    //构造函数
    ClassClock(int h, int m, int s, int ha, int ma); //构造函数
    ~ClassClock();                                   //析构函数
};
