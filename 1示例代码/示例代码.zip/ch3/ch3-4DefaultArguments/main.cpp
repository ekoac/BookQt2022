﻿#include <iostream>

using namespace std;

void printMax(int nArg1 = 2, int nArg2 = 3)
{
    cout << "Max of " << nArg1 << " and " << nArg2 << " is " << (nArg1 > nArg2 ? nArg1 : nArg2) << endl;
}

int main()
{
    printMax(10, 6); //形参nArg1=10，nArg2=6
    printMax(5);     //形参nArg1=5，nArg2为默认值3
    printMax();      //形参nArg1为默认值2，nArg2为默认值3

    return 0;
}
