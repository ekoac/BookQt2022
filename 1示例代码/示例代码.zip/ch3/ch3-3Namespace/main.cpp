﻿#include <iostream>

namespace Zhao
{
    double dSum = 1000;
}

namespace Qian
{
    double dSum = 100;
}

using namespace Zhao;

int main()
{
    std::cout << dSum << "  " << Qian::dSum << std::endl;
    dSum = 1001;
    Qian::dSum = 101;
    std::cout << dSum << "  " << Qian::dSum << std::endl;

    return 0;
}
