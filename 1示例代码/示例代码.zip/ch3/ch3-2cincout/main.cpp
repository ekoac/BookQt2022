﻿#include <iostream>

using namespace std;

int main()
{
    int nNum;
    float fNum;

    cout << "Please input an int number and a float number:" << endl;
    cin >> nNum >> fNum;
    cout << "The int number is " << nNum << '\n';
    cout << "The float number is " << fNum << endl;

    return 0;
}
