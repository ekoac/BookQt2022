﻿#include <iostream>
#include "cJSON.h"

using namespace std;

int main()
{
    cJSON *root = cJSON_CreateObject();
    cJSON_AddStringToObject(root, "Name", "Zhang San");
    cJSON_AddNumberToObject(root, "Age", 22);

    cJSON *addr = cJSON_AddObjectToObject(root, "Address");
    cJSON_AddStringToObject(addr, "City", "Nanjing");
    cJSON_AddStringToObject(addr, "Zipcode", "210000");

    cJSON *ski = cJSON_AddArrayToObject(root, "Skill");
    cJSON_AddItemToArray(ski, cJSON_CreateString("C"));
    cJSON_AddItemToArray(ski, cJSON_CreateString("C++"));
    cJSON_AddItemToArray(ski, cJSON_CreateString("Qt"));

    char *cFormattedJSON = cJSON_Print(root);
    char *cUnformattedJSON = cJSON_PrintUnformatted(root);
    cout << cFormattedJSON << endl << endl << cUnformattedJSON << endl;
    free(cFormattedJSON);
    free(cUnformattedJSON);
    cJSON_Delete(root);

    return 0;
}
