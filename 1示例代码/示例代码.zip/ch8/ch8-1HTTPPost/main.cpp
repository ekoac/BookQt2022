﻿#include <QCoreApplication>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QNetworkRequest>

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    QNetworkRequest req;
    QNetworkAccessManager manager;
    req.setUrl(QString("http://127.0.0.1:1200"));
    req.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");
    req.setHeader(QNetworkRequest::UserAgentHeader, "Mozilla/5.0 (Windows NT 10.0)");
    req.setRawHeader("Hello", "Hi");
    manager.post(req, "Content example");

    return a.exec();
}
