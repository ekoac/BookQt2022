﻿#ifndef INPUTWINDOW_H
#define INPUTWINDOW_H

#include <QWidget>
#include "ClassGY39.h"
#include "ClassPR3000.h"

namespace Ui
{
    class InputWindow;
}

class InputWindow : public QWidget
{
    Q_OBJECT

private:
    Ui::InputWindow *ui;

    ClassGY39 m_GY39InputData;
    ClassPR3000 m_PR3000InputData;

public:
    explicit InputWindow(QWidget *parent = nullptr);
    ~InputWindow();

    void showDataFromMainWindow(ClassGY39 &info39, ClassPR3000 &info3000);
    void closeEvent(QCloseEvent *event);

private slots:
    void on_pushButtonCancel_clicked();
    void on_pushButtonOK_clicked();

signals:
    void signal_sendDataToMainWindow(int nFlag, ClassGY39 &info39, ClassPR3000 &info3000);
};

#endif // INPUTWINDOW_H
