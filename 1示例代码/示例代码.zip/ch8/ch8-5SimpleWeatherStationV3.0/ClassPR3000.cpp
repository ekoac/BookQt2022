﻿#include "ClassPR3000.h"
#include <QEventLoop>
#include <QTimer>
#include "cJSON.h"

float ClassPR3000::getWindSpeed()
{
    return m_fWindSpeed;
}

int ClassPR3000::getWindDirection()
{
    return m_nWindDirection;
}

int ClassPR3000::setWindSpeed(float fWS)
{
    if (fWS < 0 || fWS > 20)
    {
        return -1;
    }
    m_fWindSpeed = fWS;
    return 0;
}

int ClassPR3000::setWindDirection(int nWD)
{
    if (nWD < 0 || nWD > 359)
    {
        return -1;
    }
    m_nWindDirection = nWD;
    return 0;
}

int ClassPR3000::crc16Verify(QByteArray qbaData, QByteArray qbaCheckSum)
{
    quint16 data8, crc16 = 0xFFFF;

    for (int i = 0; i < qbaData.size(); i++)
    {
        data8 = qbaData.at(i) & 0x00FF;
        crc16 ^= data8;
        for (int j = 0; j < 8; j++)
        {
            if (crc16 & 0x0001)
            {
                crc16 >>= 1;
                crc16 ^= 0xA001;
            }
            else
            {
                crc16 >>= 1;
            }
        }
    }
    crc16 = (crc16 >> 8) + (crc16 << 8);

    if ((crc16 / 256) == (unsigned char)qbaCheckSum.at(0))
    {
        if ((crc16 % 256) == (unsigned char)qbaCheckSum.at(1))
        {
            return 0;
        }
    }
    return 1;
}

int ClassPR3000::readSerialData(QSerialPort *serialPort)
{
    QEventLoop eventLoop; //定义事件循环

    serialPort->write(m_qbaRequestWS); //风速部分 发送问询帧
    QTimer::singleShot(100, &eventLoop, SLOT(quit()));
    eventLoop.exec();
    QByteArray qbaWSData = serialPort->readAll();

    if (0 != crc16Verify(qbaWSData.left(5), qbaWSData.right(2)))
    {
        return -1;
    }

    float fWindSpeed = (qbaWSData.at(3) * 256 + qbaWSData.at(4)) / 10.0;
    if (setWindSpeed(fWindSpeed) != 0)
    {
        return -2;
    }

    serialPort->write(m_qbaRequestWD); //风向部分 发送问询帧
    QTimer::singleShot(100, &eventLoop, SLOT(quit()));
    eventLoop.exec();
    QByteArray qbaWDData = serialPort->readAll();

    if (0 != crc16Verify(qbaWDData.left(7), qbaWDData.right(2)))
    {
        return -3;
    }

    int nWindDirection = ((unsigned char)qbaWDData.at(5) * 256 + (unsigned char)qbaWDData.at(6));
    if (setWindDirection(nWindDirection) != 0)
    {
        return -4;
    }
    return 0;
}

QByteArray ClassPR3000::dataToHex()
{
    QByteArray qbaHexData;
    qbaHexData.append(QString("%1").arg(getWindSpeed(), 4));
    qbaHexData.append(QString("%1").arg(getWindDirection(), 3));
    return qbaHexData;
}

QByteArray ClassPR3000::dataToJSON()
{
    cJSON *root, *array1, *array2, *obj1, *obj2;

    root = cJSON_CreateObject();
    array1 = cJSON_AddArrayToObject(root, "datastreams");

    cJSON_AddItemToArray(array1, obj1 = cJSON_CreateObject());
    cJSON_AddStringToObject(obj1, "id", "WindSpeed");
    array2 = cJSON_AddArrayToObject(obj1, "datapoints");
    cJSON_AddItemToArray(array2, obj2 = cJSON_CreateObject());
    cJSON_AddNumberToObject(obj2, "value", int(getWindSpeed() * 100) / 100.0);

    cJSON_AddItemToArray(array1, obj1 = cJSON_CreateObject());
    cJSON_AddStringToObject(obj1, "id", "WindDirection");
    array2 = cJSON_AddArrayToObject(obj1, "datapoints");
    cJSON_AddItemToArray(array2, obj2 = cJSON_CreateObject());
    cJSON_AddNumberToObject(obj2, "value", (int(getWindDirection() * 10)) / 10.0);

    char *cUnformattedJSON = cJSON_PrintUnformatted(root);
    QByteArray JSONData = QByteArray(cUnformattedJSON);
    free(cUnformattedJSON);
    cJSON_Delete(root);

    return JSONData;
}
