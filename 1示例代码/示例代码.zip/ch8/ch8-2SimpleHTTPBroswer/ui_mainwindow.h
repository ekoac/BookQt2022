/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QLineEdit *lineEditURL;
    QTextEdit *textEditWebpage;
    QPushButton *pushButtonGo;
    QLabel *label;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(800, 462);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        lineEditURL = new QLineEdit(centralwidget);
        lineEditURL->setObjectName(QString::fromUtf8("lineEditURL"));
        lineEditURL->setGeometry(QRect(70, 20, 581, 30));
        textEditWebpage = new QTextEdit(centralwidget);
        textEditWebpage->setObjectName(QString::fromUtf8("textEditWebpage"));
        textEditWebpage->setGeometry(QRect(10, 60, 781, 391));
        pushButtonGo = new QPushButton(centralwidget);
        pushButtonGo->setObjectName(QString::fromUtf8("pushButtonGo"));
        pushButtonGo->setGeometry(QRect(670, 20, 111, 30));
        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(10, 20, 51, 30));
        MainWindow->setCentralWidget(centralwidget);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        pushButtonGo->setText(QCoreApplication::translate("MainWindow", "\346\211\223\345\274\200\347\275\221\351\241\265", nullptr));
        label->setText(QCoreApplication::translate("MainWindow", "\347\275\221\345\235\200\357\274\232", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
