﻿#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QNetworkRequest>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    m_manager = new QNetworkAccessManager(this);                                                            //分配内存
    connect(m_manager, SIGNAL(finished(QNetworkReply *)), this, SLOT(slot_webpageLoaded(QNetworkReply *))); //绑定完成信号
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::slot_webpageLoaded(QNetworkReply *reply)
{
    QString qstrReply = reply->readAll();
    ui->textEditWebpage->setText(qstrReply);
}

void MainWindow::on_pushButtonGo_clicked()
{
    QString url = ui->lineEditURL->text(); //从文本框读取网址
    QNetworkRequest req;                   //定义网路请求
    req.setUrl(QUrl(url));                 //设置请求网址
    m_manager->get(req);                   //发送网络请求
}
