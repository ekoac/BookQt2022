﻿#include <iostream>
#include "cJSON.h"

using namespace std;

int main()
{
    char message[] = "{\"Name\":\"Zhang San\",\"Age\":22,\"Address\":{\"City\":\"Nanjing\",\"Zipcode\":\"210000\"},\"Skill\":[\"C\",\"C++\",\"Qt\"]}";

    // 定义变量，保存数据的各个值
    cJSON *root = NULL;
    cJSON *name = NULL;
    cJSON *age = NULL;
    cJSON *address = NULL;
    cJSON *address_city = NULL;
    cJSON *address_zipcode = NULL;
    cJSON *skill = NULL;
    int skill_array_size = 0, i = 0;
    cJSON *skill_item = NULL;

    // 解析JSON数据
    root = cJSON_Parse(message);

    // 根据名称提取键值对
    name = cJSON_GetObjectItem(root, "Name");
    age = cJSON_GetObjectItem(root, "Age");

    cout << "Name: " << name->valuestring << endl;
    cout << "Age: " << age->valueint << endl;

    // 解析嵌套JSON数据
    address = cJSON_GetObjectItem(root, "Address");            //提取嵌套对象
    address_city = cJSON_GetObjectItem(address, "City");       //提取值
    address_zipcode = cJSON_GetObjectItem(address, "Zipcode"); //提取值

    cout << "Address - City: " << address_city->valuestring << endl;
    cout << "Address - Zipcode: " << address_zipcode->valuestring << endl;

    // 解析数组
    skill = cJSON_GetObjectItem(root, "Skill");
    skill_array_size = cJSON_GetArraySize(skill);
    for (i = 0; i < skill_array_size; i++)
    {
        skill_item = cJSON_GetArrayItem(skill, i);
        cout << "Skill " << i + 1 << ": " << skill_item->valuestring << endl;
    }

    cJSON_Delete(root);

    return 0;
}
