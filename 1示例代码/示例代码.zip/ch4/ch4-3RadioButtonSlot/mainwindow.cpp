#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_radioButton1_clicked()
{
    ui->label->setText("radioButton1");
}

void MainWindow::on_radioButton2_clicked()
{
    ui->label->setText("radioButton2");
}
