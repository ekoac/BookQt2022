﻿#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "ui_mainwindow.h"

#include <time.h>
#include <QtNetwork>
#include <QTcpSocket>
#include <QTcpServer>
#include <QNetworkReply>
#include <QNetworkRequest>
#include <QNetworkAccessManager>

#include "common.h"
#include "classtcpthread.h"
#include "structdevicedata.h"

QT_BEGIN_NAMESPACE
namespace Ui
{
    class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void printLog(QString log1, QString log2 = "");
    void getLocalIP(); // 获取本机IP地址
    ClassTCPThread *socketThread;

private slots:
    void on_pushButtonTCPStartListen_clicked();
    void on_pushButtonClearData_clicked();
    void on_pushButtonClearLog_clicked();

    void slot_TCPNewConnection();
    void slot_parseHEXData();
    void slot_updateUI();
    void slot_showMessageFromThread(QString message);

signals:
    void signal_newData();

private:
    Ui::MainWindow *ui;

    QTcpServer *m_TCPServer; // TCP服务器
    QTcpSocket *m_TCPSocket; // TCP通讯的Socket

    QTimer m_timerDataProcess;

    StructDeviceData m_deviceData;
};
#endif // MAINWINDOW_H
