﻿#include "classtcpthread.h"

#include <QDebug>
#include <QtNetwork>

ClassTCPThread::ClassTCPThread(QTcpSocket *tcp) : QThread()
{
    m_tcpsocket = tcp;
}

void ClassTCPThread::run()
{
    qDebug() << "New thread";
    connect(this->m_tcpsocket, SIGNAL(readyRead()), this, SLOT(slot_readSocketData()));
    this->exec();
}

ClassTCPThread::~ClassTCPThread()
{
    disconnect(this->m_tcpsocket, SIGNAL(readyRead()), this, SLOT(slot_readSocketData()));
    m_tcpsocket->close();
    m_tcpsocket->deleteLater();
    qDebug() << "Thread quit";
}

void ClassTCPThread::slot_readSocketData()
{
    QByteArray requestData;

    while (m_tcpsocket->waitForReadyRead(500))
    {
        requestData += m_tcpsocket->readAll();
        if (requestData.length() > 7)
        {
            break;
        }
    }
    requestData += m_tcpsocket->readAll();

    qDebug() << requestData;

    if (requestData.startsWith('*') and requestData.endsWith('*'))
    {
        emit signal_messageToMain(QString("收到鉴权信息：") + QString::fromUtf8(requestData));

        // 删除开头和结尾的星号
        requestData = requestData.mid(1, requestData.length() - 2);

        // 使用 '#' 字符进行分割
        QByteArrayList parts = requestData.split('#');

        // 确保有足够的部分可用
        if (parts.size() >= 3)
        {
            productID = parts[0];
            authCode = parts[1];
            script = parts[2];
        }
        else
        {
            return;
        }
    }
    else if (requestData.length() == 33)
    {
        dataQueue.enqueue(QByteArray("").append(productID).append('#').append(authCode).append('#').append(requestData));
    }

    m_tcpsocket->write("received");
    m_tcpsocket->flush();
    m_tcpsocket->waitForBytesWritten();
}
