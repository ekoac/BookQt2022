﻿#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QDebug>
#include <QMouseEvent>
#include <QNetworkReply>
#include <QNetworkRequest>
#include <QNetworkAccessManager>

#include "common.h"
#include "classtcpthread.h"
#include "structdevicedata.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    ui->tableWidgetDataList->horizontalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);

    m_TCPServer = new QTcpServer();
    connect(m_TCPServer, SIGNAL(newConnection()), this, SLOT(slot_TCPNewConnection()));

    connect(this, SIGNAL(signal_newData()), this, SLOT(slot_updateUI()));

    getLocalIP();

    connect(&m_timerDataProcess, SIGNAL(timeout()), this, SLOT(slot_parseHEXData()));
}

MainWindow::~MainWindow()
{
    delete m_TCPSocket;
    delete m_TCPServer;
    delete ui;
}

void MainWindow::getLocalIP() // 获取本机IPv4地址
{
    QList<QHostAddress> addList = QNetworkInterface::allAddresses();

    foreach (QHostAddress temp, addList)
    {
        if (QAbstractSocket::IPv4Protocol == temp.protocol())
        {
            ui->comboBoxIPList->addItem(temp.toString());
        }
    }
    ui->comboBoxIPList->model()->sort(0);
    ui->comboBoxIPList->setCurrentIndex(0);
}

void MainWindow::on_pushButtonTCPStartListen_clicked()
{
    if (!m_TCPServer->isListening())
    {
        QHostAddress addr(ui->comboBoxIPList->currentText());
        quint16 port = ui->lineEditPort->text().toInt();
        if (!m_TCPServer->listen(addr, port))
        {
            printLog("监听失败");
            return;
        }
        printLog(QString("开始监听，监听地址：%1:%2").arg(m_TCPServer->serverAddress().toString()).arg(QString::number(m_TCPServer->serverPort())));
        ui->pushButtonTCPStartListen->setText("停止监听");
        ui->comboBoxIPList->setEnabled(false);
        ui->lineEditPort->setEnabled(false);
        m_timerDataProcess.start(5000);
    }
    else if (m_TCPServer->isListening())
    {
        ui->pushButtonTCPStartListen->setText("开始监听");
        printLog("停止监听");
        ui->comboBoxIPList->setEnabled(true);
        ui->lineEditPort->setEnabled(true);
        m_TCPServer->close(); // 停止监听
        m_timerDataProcess.stop();
    }
}

void MainWindow::slot_TCPNewConnection()
{
    m_TCPSocket = m_TCPServer->nextPendingConnection();    // 创建socket
    if (nullptr == m_TCPSocket || !m_TCPSocket->isValid()) // 加判断套接字是否有效，客户端如果有心跳重连功能不判断会导致套接字失败
    {
        return;
    }

    socketThread = new ClassTCPThread(m_TCPSocket);
    socketThread->start();
    connect(socketThread, SIGNAL(signal_messageToMain(QString)), this, SLOT(slot_showMessageFromThread(QString)));
}

void MainWindow::printLog(QString log1, QString log2)
{
    QTime timeNow = QTime::currentTime();
    QString data = QString("%1  %2  %3").arg(timeNow.toString()).arg(log1).arg(log2);
    ui->textEditLog->append(data);
    if (ui->checkBoxLogScrollToButtom->isChecked())
    {
        ui->textEditLog->moveCursor(QTextCursor::End);
    }
}

void MainWindow::slot_parseHEXData()
{
    if (dataQueue.length() > 0)
    {
        printLog("开始处理数据，共" + QString::number(dataQueue.length()) + "条");
    }

    while (!(dataQueue.isEmpty()))
    {
        QByteArray data2 = dataQueue.dequeue();

        m_deviceData.initialize();

        QByteArrayList lineList = data2.split('#');

        m_deviceData.qdtTime = QDateTime::currentDateTime();
        m_deviceData.productID = QString::fromUtf8(lineList[0]);
        m_deviceData.authCode = QString::fromUtf8(lineList[1]);

        m_deviceData.nHumidity = lineList[2].left(3).toInt();
        m_deviceData.fTemperature = lineList[2].mid(3, 6).toDouble();
        m_deviceData.nAltitude = lineList[2].mid(9, 4).toInt();
        m_deviceData.fPressure = lineList[2].mid(13, 7).toDouble();
        m_deviceData.nIllumination = lineList[2].mid(20, 6).toInt();
        m_deviceData.fWindSpeed = lineList[2].mid(26, 4).toDouble();
        m_deviceData.nWindDirection = lineList[2].mid(30, 3).toInt();
        m_deviceData.nGY39ValidFlag = 1;
        m_deviceData.nPR3000ValidFlag = 1;

        emit signal_newData();
    }
    return;
}

void MainWindow::slot_updateUI()
{
    int rowCount = ui->tableWidgetDataList->rowCount();
    ui->tableWidgetDataList->insertRow(rowCount);

    ui->tableWidgetDataList->setItem(rowCount, 0, new QTableWidgetItem(m_deviceData.qdtTime.time().toString()));
    ui->tableWidgetDataList->setItem(rowCount, 1, new QTableWidgetItem(m_deviceData.productID));
    ui->tableWidgetDataList->setItem(rowCount, 2, new QTableWidgetItem(m_deviceData.authCode));

    if (m_deviceData.nGY39ValidFlag == 1)
    {
        ui->tableWidgetDataList->setItem(rowCount, 3, new QTableWidgetItem(QString::number(m_deviceData.nHumidity)));
        ui->tableWidgetDataList->setItem(rowCount, 4, new QTableWidgetItem(QString::number(m_deviceData.fTemperature)));
        ui->tableWidgetDataList->setItem(rowCount, 5, new QTableWidgetItem(QString::number(m_deviceData.nAltitude)));
        ui->tableWidgetDataList->setItem(rowCount, 6, new QTableWidgetItem(QString::number(m_deviceData.fPressure)));
        ui->tableWidgetDataList->setItem(rowCount, 7, new QTableWidgetItem(QString::number(m_deviceData.nIllumination)));
    }
    else
    {
        ui->tableWidgetDataList->setItem(rowCount, 3, new QTableWidgetItem("-"));
        ui->tableWidgetDataList->setItem(rowCount, 4, new QTableWidgetItem("-"));
        ui->tableWidgetDataList->setItem(rowCount, 5, new QTableWidgetItem("-"));
        ui->tableWidgetDataList->setItem(rowCount, 6, new QTableWidgetItem("-"));
        ui->tableWidgetDataList->setItem(rowCount, 7, new QTableWidgetItem("-"));
    }

    if (m_deviceData.nPR3000ValidFlag == 1)
    {
        ui->tableWidgetDataList->setItem(rowCount, 8, new QTableWidgetItem(QString::number(m_deviceData.fWindSpeed)));
        ui->tableWidgetDataList->setItem(rowCount, 9, new QTableWidgetItem(QString::number(m_deviceData.nWindDirection)));
    }
    else
    {
        ui->tableWidgetDataList->setItem(rowCount, 8, new QTableWidgetItem("-"));
        ui->tableWidgetDataList->setItem(rowCount, 9, new QTableWidgetItem("-"));
    }

    for (int i = 0; i <= 9; i++)
    {
        ui->tableWidgetDataList->item(rowCount, i)->setTextAlignment(Qt::AlignHCenter | Qt::AlignVCenter);
    }

    if (ui->checkBoxDataScrollToButtom->isChecked())
    {
        ui->tableWidgetDataList->scrollToBottom();
    }
}

void MainWindow::on_pushButtonClearData_clicked()
{
    int rowNum = ui->tableWidgetDataList->rowCount();
    for (int i = 0; i < rowNum; i++) // 清空列表
    {
        ui->tableWidgetDataList->removeRow(0);
    }
    printLog("数据列表已清空。");
}

void MainWindow::on_pushButtonClearLog_clicked()
{
    ui->textEditLog->clear();
}

void MainWindow::slot_showMessageFromThread(QString message)
{
    printLog(message);
}
