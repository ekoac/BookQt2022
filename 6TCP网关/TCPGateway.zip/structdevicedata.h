﻿#ifndef STRUCTDEVICEDATA_H
#define STRUCTDEVICEDATA_H

#include <QDateTime>

typedef struct _StructDeviceData
{
    QDateTime qdtTime;
    QString productID;
    QString authCode;
    int nHumidity;
    float fTemperature;
    int nAltitude;
    float fPressure;
    int nIllumination;
    float fWindSpeed;
    int nWindDirection;

    int nGY39ValidFlag;
    int nPR3000ValidFlag;

    _StructDeviceData()
    {
        this->nHumidity = 0;
        this->nAltitude = 0;
        this->fPressure = 0;
        this->nIllumination = 0;
        this->fTemperature=0;
        this->fWindSpeed = 0;
        this->nWindDirection = 0;
        this->nGY39ValidFlag = 0;
        this->nPR3000ValidFlag = 0;
    };

    void initialize()
    {
        qdtTime.setDate(QDate()); // 设置日期为无效日期
        qdtTime.setTime(QTime()); // 设置时间为无效时间
        productID = "";
        authCode = "";

        this->nHumidity = 0;
        this->nAltitude = 0;
        this->fPressure = 0;
        this->nIllumination = 0;
        this->fWindSpeed = 0;
        this->nWindDirection = 0;
        this->fTemperature=0;
        this->nGY39ValidFlag = 0;
        this->nPR3000ValidFlag = 0;
    }

} StructDeviceData;

#endif // STRUCTDEVICEDATA_H
