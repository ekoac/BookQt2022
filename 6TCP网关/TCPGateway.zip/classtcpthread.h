﻿#ifndef ClassTCPThread_H
#define ClassTCPThread_H

#include <QThread>
#include <QWidget>
#include <QtNetwork>

#include "common.h"

class ClassTCPThread : public QThread
{
    Q_OBJECT
public:
    ClassTCPThread(QTcpSocket *tcp);
    ~ClassTCPThread();
    QTcpSocket *m_tcpsocket;

private:
    virtual void run();

    QByteArray productID;
    QByteArray authCode;
    QByteArray script;

private slots:
    void slot_readSocketData();

signals:
    void signal_messageToMain(QString message);
};

#endif // ClassTCPThread_H
