/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QLineEdit *lineEditPort;
    QPushButton *pushButtonTCPStartListen;
    QComboBox *comboBoxIPList;
    QLabel *label_2;
    QLabel *label;
    QTabWidget *tabWidget;
    QWidget *tab;
    QPushButton *pushButtonClearData;
    QTableWidget *tableWidgetDataList;
    QCheckBox *checkBoxDataScrollToButtom;
    QWidget *tab_3;
    QPushButton *pushButtonClearLog;
    QTextEdit *textEditLog;
    QCheckBox *checkBoxLogScrollToButtom;
    QWidget *tab_2;
    QTextEdit *textEdit;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(1611, 728);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        lineEditPort = new QLineEdit(centralwidget);
        lineEditPort->setObjectName(QString::fromUtf8("lineEditPort"));
        lineEditPort->setGeometry(QRect(430, 20, 101, 30));
        lineEditPort->setAlignment(Qt::AlignCenter);
        pushButtonTCPStartListen = new QPushButton(centralwidget);
        pushButtonTCPStartListen->setObjectName(QString::fromUtf8("pushButtonTCPStartListen"));
        pushButtonTCPStartListen->setGeometry(QRect(550, 20, 141, 30));
        comboBoxIPList = new QComboBox(centralwidget);
        comboBoxIPList->setObjectName(QString::fromUtf8("comboBoxIPList"));
        comboBoxIPList->setGeometry(QRect(120, 20, 181, 30));
        label_2 = new QLabel(centralwidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(330, 20, 81, 30));
        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(30, 20, 81, 30));
        tabWidget = new QTabWidget(centralwidget);
        tabWidget->setObjectName(QString::fromUtf8("tabWidget"));
        tabWidget->setGeometry(QRect(10, 70, 1591, 641));
        tab = new QWidget();
        tab->setObjectName(QString::fromUtf8("tab"));
        pushButtonClearData = new QPushButton(tab);
        pushButtonClearData->setObjectName(QString::fromUtf8("pushButtonClearData"));
        pushButtonClearData->setGeometry(QRect(1450, 570, 111, 30));
        tableWidgetDataList = new QTableWidget(tab);
        if (tableWidgetDataList->columnCount() < 10)
            tableWidgetDataList->setColumnCount(10);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        tableWidgetDataList->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        tableWidgetDataList->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        tableWidgetDataList->setHorizontalHeaderItem(2, __qtablewidgetitem2);
        QTableWidgetItem *__qtablewidgetitem3 = new QTableWidgetItem();
        tableWidgetDataList->setHorizontalHeaderItem(3, __qtablewidgetitem3);
        QTableWidgetItem *__qtablewidgetitem4 = new QTableWidgetItem();
        tableWidgetDataList->setHorizontalHeaderItem(4, __qtablewidgetitem4);
        QTableWidgetItem *__qtablewidgetitem5 = new QTableWidgetItem();
        tableWidgetDataList->setHorizontalHeaderItem(5, __qtablewidgetitem5);
        QTableWidgetItem *__qtablewidgetitem6 = new QTableWidgetItem();
        tableWidgetDataList->setHorizontalHeaderItem(6, __qtablewidgetitem6);
        QTableWidgetItem *__qtablewidgetitem7 = new QTableWidgetItem();
        tableWidgetDataList->setHorizontalHeaderItem(7, __qtablewidgetitem7);
        QTableWidgetItem *__qtablewidgetitem8 = new QTableWidgetItem();
        tableWidgetDataList->setHorizontalHeaderItem(8, __qtablewidgetitem8);
        QTableWidgetItem *__qtablewidgetitem9 = new QTableWidgetItem();
        tableWidgetDataList->setHorizontalHeaderItem(9, __qtablewidgetitem9);
        tableWidgetDataList->setObjectName(QString::fromUtf8("tableWidgetDataList"));
        tableWidgetDataList->setGeometry(QRect(10, 20, 1561, 541));
        tableWidgetDataList->setSelectionBehavior(QAbstractItemView::SelectRows);
        tableWidgetDataList->setSortingEnabled(false);
        tableWidgetDataList->setCornerButtonEnabled(false);
        tableWidgetDataList->horizontalHeader()->setHighlightSections(false);
        tableWidgetDataList->horizontalHeader()->setProperty("showSortIndicator", QVariant(false));
        tableWidgetDataList->horizontalHeader()->setStretchLastSection(false);
        checkBoxDataScrollToButtom = new QCheckBox(tab);
        checkBoxDataScrollToButtom->setObjectName(QString::fromUtf8("checkBoxDataScrollToButtom"));
        checkBoxDataScrollToButtom->setGeometry(QRect(1280, 570, 141, 30));
        checkBoxDataScrollToButtom->setChecked(true);
        tabWidget->addTab(tab, QString());
        tab_3 = new QWidget();
        tab_3->setObjectName(QString::fromUtf8("tab_3"));
        pushButtonClearLog = new QPushButton(tab_3);
        pushButtonClearLog->setObjectName(QString::fromUtf8("pushButtonClearLog"));
        pushButtonClearLog->setGeometry(QRect(1440, 570, 131, 31));
        textEditLog = new QTextEdit(tab_3);
        textEditLog->setObjectName(QString::fromUtf8("textEditLog"));
        textEditLog->setGeometry(QRect(10, 20, 1561, 541));
        checkBoxLogScrollToButtom = new QCheckBox(tab_3);
        checkBoxLogScrollToButtom->setObjectName(QString::fromUtf8("checkBoxLogScrollToButtom"));
        checkBoxLogScrollToButtom->setGeometry(QRect(1270, 570, 141, 30));
        checkBoxLogScrollToButtom->setChecked(true);
        tabWidget->addTab(tab_3, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QString::fromUtf8("tab_2"));
        textEdit = new QTextEdit(tab_2);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));
        textEdit->setGeometry(QRect(10, 20, 1561, 581));
        textEdit->setAcceptRichText(false);
        tabWidget->addTab(tab_2, QString());
        MainWindow->setCentralWidget(centralwidget);

        retranslateUi(MainWindow);

        tabWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "TCP\346\260\224\350\261\241\347\253\231\347\275\221\345\205\263", nullptr));
        lineEditPort->setText(QCoreApplication::translate("MainWindow", "1811", nullptr));
        pushButtonTCPStartListen->setText(QCoreApplication::translate("MainWindow", "\345\274\200\345\247\213\347\233\221\345\220\254", nullptr));
        label_2->setText(QCoreApplication::translate("MainWindow", "\347\233\221\345\220\254\347\253\257\345\217\243\357\274\232", nullptr));
        label->setText(QCoreApplication::translate("MainWindow", "\347\233\221\345\220\254\345\234\260\345\235\200\357\274\232", nullptr));
        pushButtonClearData->setText(QCoreApplication::translate("MainWindow", "\346\270\205\347\251\272\346\225\260\346\215\256", nullptr));
        QTableWidgetItem *___qtablewidgetitem = tableWidgetDataList->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QCoreApplication::translate("MainWindow", "\346\227\266\351\227\264", nullptr));
        QTableWidgetItem *___qtablewidgetitem1 = tableWidgetDataList->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QCoreApplication::translate("MainWindow", "\344\272\247\345\223\201ID", nullptr));
        QTableWidgetItem *___qtablewidgetitem2 = tableWidgetDataList->horizontalHeaderItem(2);
        ___qtablewidgetitem2->setText(QCoreApplication::translate("MainWindow", "\346\216\210\346\235\203\347\240\201", nullptr));
        QTableWidgetItem *___qtablewidgetitem3 = tableWidgetDataList->horizontalHeaderItem(3);
        ___qtablewidgetitem3->setText(QCoreApplication::translate("MainWindow", "\346\271\277\345\272\246\357\274\210%RH\357\274\211", nullptr));
        QTableWidgetItem *___qtablewidgetitem4 = tableWidgetDataList->horizontalHeaderItem(4);
        ___qtablewidgetitem4->setText(QCoreApplication::translate("MainWindow", "\346\270\251\345\272\246\357\274\210\342\204\203\357\274\211", nullptr));
        QTableWidgetItem *___qtablewidgetitem5 = tableWidgetDataList->horizontalHeaderItem(5);
        ___qtablewidgetitem5->setText(QCoreApplication::translate("MainWindow", "\346\265\267\346\213\224\357\274\210m\357\274\211", nullptr));
        QTableWidgetItem *___qtablewidgetitem6 = tableWidgetDataList->horizontalHeaderItem(6);
        ___qtablewidgetitem6->setText(QCoreApplication::translate("MainWindow", "\346\260\224\345\216\213\357\274\210kPa\357\274\211", nullptr));
        QTableWidgetItem *___qtablewidgetitem7 = tableWidgetDataList->horizontalHeaderItem(7);
        ___qtablewidgetitem7->setText(QCoreApplication::translate("MainWindow", "\347\205\247\345\272\246\357\274\210lux\357\274\211", nullptr));
        QTableWidgetItem *___qtablewidgetitem8 = tableWidgetDataList->horizontalHeaderItem(8);
        ___qtablewidgetitem8->setText(QCoreApplication::translate("MainWindow", "\351\243\216\351\200\237\357\274\210m/s\357\274\211", nullptr));
        QTableWidgetItem *___qtablewidgetitem9 = tableWidgetDataList->horizontalHeaderItem(9);
        ___qtablewidgetitem9->setText(QCoreApplication::translate("MainWindow", "\351\243\216\345\220\221\357\274\210\302\260\357\274\211", nullptr));
        checkBoxDataScrollToButtom->setText(QCoreApplication::translate("MainWindow", "\350\207\252\345\212\250\346\273\232\345\212\250\345\210\260\345\272\225\351\203\250", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab), QCoreApplication::translate("MainWindow", "\346\225\260\346\215\256\346\216\245\346\224\266", nullptr));
        pushButtonClearLog->setText(QCoreApplication::translate("MainWindow", "\346\270\205\347\251\272\346\227\245\345\277\227", nullptr));
        checkBoxLogScrollToButtom->setText(QCoreApplication::translate("MainWindow", "\350\207\252\345\212\250\346\273\232\345\212\250\345\210\260\345\272\225\351\203\250", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_3), QCoreApplication::translate("MainWindow", "\350\277\220\350\241\214\346\227\245\345\277\227", nullptr));
        textEdit->setHtml(QCoreApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'SimSun'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">\346\234\254\347\250\213\345\272\217\350\203\275\351\205\215\345\220\210\347\254\254\344\270\203\347\253\240\347\232\204\346\260\224\350\261\241\347\253\231\347\250\213\345\272\217\350\277\220\350\241\214\357\274\214\346\216\245\346\224\266\351\200\232\350\277\207TCP\345\215\217\350\256\256\345\217\221\351\200\201\347\232\204HEX\346\225\260\346\215\256\343\200\202</p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><br /></p>\n"
"<p style=\" margin-top:0px; margin-"
                        "bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">\344\273\245\344\270\213\346\230\257\347\254\254\344\270\203\347\253\240\346\260\224\350\261\241\347\253\231\347\244\272\344\276\213\344\273\243\347\240\201\345\217\221\351\200\201\347\232\204\344\270\200\347\273\204HEX\346\225\260\346\215\256\357\274\232</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">20 35 33 / 20 20 20 20 32 32 / 20 31 33 32 / 31 30 35 2E 36 31 35 / 31 30 33 30 30 30 / 20 31 2E 33 / 32 37 36</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">\346\271\277\345\272\246      \346\270\251\345\272\246                 \346\265\267\346\213\224          \346\260\224\345\216\213                   \347\205\247\345\272\246                \351\243\216\351\200\237          \351\243\216\345\220\221</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:"
                        "0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">\345\205\266\344\270\255\345\220\204\351\203\250\345\210\206\345\220\253\344\271\211\344\270\272\357\274\210_\344\273\243\350\241\250\347\251\272\346\240\274\357\274\211\357\274\232</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">    \346\271\277\345\272\246\357\274\214\351\225\277\345\272\2463\345\255\227\350\212\202\357\274\214\346\225\264\346\225\260\357\274\214\345\246\202_56\357\274\214\345\215\225\344\275\215\344\270\272%RH</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">    \346\270\251\345\272\246\357\274\214\351\225\277\345\272\2466\345\255\227\350\212\202\357\274\214\346\265\256\347\202\271\346\225\260\357\274\214\345\246\202-25.48\346\210\226_25.48\357\274\214\345\215\225\344\275\215\344\270\272\342\204\203</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; m"
                        "argin-right:0px; -qt-block-indent:0; text-indent:0px;\">    \346\265\267\346\213\224\357\274\214\351\225\277\345\272\2464\345\255\227\350\212\202\357\274\214\346\225\264\346\225\260\357\274\214\345\246\202-160\346\210\2262310\357\274\214\345\215\225\344\275\215\344\270\272m</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">    \346\260\224\345\216\213\357\274\214\351\225\277\345\272\2467\345\255\227\350\212\202\357\274\214\346\265\256\347\202\271\346\225\260\357\274\214\345\246\202101.325\357\274\214\345\215\225\344\275\215\344\270\272kPa</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">    \347\205\247\345\272\246\357\274\214\351\225\277\345\272\2466\345\255\227\350\212\202\357\274\214\346\225\264\346\225\260\357\274\214\345\246\202_ _ 1200\346\210\226120000\357\274\214\345\215\225\344\275\215\344\270\272lux</p>\n"
"<p style=\" margin-top:0px; margin-bo"
                        "ttom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">    \351\243\216\351\200\237\357\274\214\351\225\277\345\272\2464\345\255\227\350\212\202\357\274\214\346\265\256\347\202\271\346\225\260\357\274\214\345\246\202_1.2\346\210\22611.5\357\274\214\345\215\225\344\275\215\344\270\272m/s</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">    \351\243\216\345\220\221\357\274\214\351\225\277\345\272\2463\345\255\227\350\212\202\357\274\214\346\225\264\346\225\260\357\274\214\345\246\20212\346\210\226315\357\274\214\345\215\225\344\275\215\344\270\272\302\260</p></body></html>", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QCoreApplication::translate("MainWindow", "\347\250\213\345\272\217\350\257\264\346\230\216", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
