﻿#ifndef COMMON_H
#define COMMON_H

#include <QQueue>

extern QQueue<QByteArray> dataQueue;

#endif // COMMON_H
