﻿#ifndef COMMON_H
#define COMMON_H

#include <QQueue>

extern QQueue<QString> dataQueue;

#endif // COMMON_H
