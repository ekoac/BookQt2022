﻿#include "classtcpthread.h"

#include <QDebug>
#include <QtNetwork>

ClassTCPThread::ClassTCPThread(QTcpSocket *tcp) : QThread()
{
    m_tcpsocket = tcp;
}

void ClassTCPThread::run()
{
    qDebug() << "New thread";
    connect(this->m_tcpsocket, SIGNAL(readyRead()), this, SLOT(slot_readSocketData()));
    this->exec();
}

ClassTCPThread::~ClassTCPThread()
{
    disconnect(this->m_tcpsocket, SIGNAL(readyRead()), this, SLOT(slot_readSocketData()));
    m_tcpsocket->close();
    m_tcpsocket->deleteLater();
    qDebug() << "Thread quit";
}

void ClassTCPThread::slot_readSocketData()
{
    QByteArray requestData;

    while (m_tcpsocket->waitForReadyRead(500))
    {
        requestData += m_tcpsocket->readAll();
        if (requestData.contains("\r\n\r\n"))
        {
            break;
        }
    }
    requestData += m_tcpsocket->readAll();

    if (requestData.length() < 100)
    {
        return;
    }

    QString requestString = QString::fromUtf8(requestData);
    QStringList requestLines = requestString.split('\n');
    QString postLine = requestLines.first();
    QString apiKey;
    QString deviceId;

    if (postLine.startsWith("POST"))
    {
        int deviceIdStart = postLine.indexOf("/devices/") + 9;
        int deviceIdEnd = postLine.indexOf("/datapoints");
        deviceId = postLine.mid(deviceIdStart, deviceIdEnd - deviceIdStart);

        for (const QString &line : requestLines)
        {
            if (line.startsWith("api-key: "))
            {
                apiKey = line.mid(9).trimmed();
                break;
            }
        }

        qDebug() << "Device ID:" << deviceId;
        qDebug() << "API Key:" << apiKey;
    }

    dataQueue.enqueue(QString("%1#%2#%3").arg(deviceId).arg(apiKey).arg(QString::fromUtf8(requestData)));

    m_tcpsocket->write("HTTP/1.1 200 OK\r\n\r\n POST received");
    m_tcpsocket->flush();
    m_tcpsocket->waitForBytesWritten();
    m_tcpsocket->close();
}
