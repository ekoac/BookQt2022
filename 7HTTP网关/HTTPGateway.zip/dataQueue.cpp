﻿// dataQueue.cpp

#include "common.h"  // 包含声明dataQueue的头文件

QQueue<QString> dataQueue; // 定义全局队列

void initQueue() {
  // 初始化队列,如果需要的话
}

bool queueEmpty() {
  return dataQueue.empty();
}

void enqueue(const QString &str) {
  dataQueue.enqueue(str);
}

QString dequeue() {
  return dataQueue.dequeue();
}

// 其它对全局队列的操作函数
