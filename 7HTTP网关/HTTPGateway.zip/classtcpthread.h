﻿#ifndef ClassTCPThread_H
#define ClassTCPThread_H

#include <QThread>
#include <QWidget>
#include <QtNetwork>

#include "common.h"

class ClassTCPThread : public QThread
{
    Q_OBJECT
public:
    ClassTCPThread(QTcpSocket *tcp);
    ~ClassTCPThread();
    QTcpSocket *m_tcpsocket;

private:
    virtual void run();

private slots:
    void slot_readSocketData();
};

#endif // ClassTCPThread_H
