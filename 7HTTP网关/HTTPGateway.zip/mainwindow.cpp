﻿#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QDebug>
#include <QMouseEvent>
#include <QNetworkReply>
#include <QNetworkRequest>
#include <QNetworkAccessManager>

#include "cJSON.h"
#include "common.h"
#include "classtcpthread.h"
#include "structdevicedata.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    ui->tableWidgetDataList->horizontalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);

    m_TCPServer = new QTcpServer();
    connect(m_TCPServer, SIGNAL(newConnection()), this, SLOT(slot_TCPNewConnection()));

    connect(this, SIGNAL(signal_newData()), this, SLOT(slot_updateUI()));

    getLocalIP();

    connect(&m_timerDataProcess, SIGNAL(timeout()), this, SLOT(slot_parseJSONData()));
}

MainWindow::~MainWindow()
{
    delete m_TCPSocket;
    delete m_TCPServer;
    delete ui;
}

void MainWindow::getLocalIP() // 获取本机IPv4地址
{
    QList<QHostAddress> addList = QNetworkInterface::allAddresses();

    foreach (QHostAddress temp, addList)
    {
        if (QAbstractSocket::IPv4Protocol == temp.protocol())
        {
            ui->comboBoxIPList->addItem(temp.toString());
        }
    }
    ui->comboBoxIPList->model()->sort(0);
    ui->comboBoxIPList->setCurrentIndex(0);
}

void MainWindow::on_pushButtonTCPStartListen_clicked()
{
    if (!m_TCPServer->isListening())
    {
        QHostAddress addr(ui->comboBoxIPList->currentText());
        quint16 port = ui->lineEditPort->text().toInt();
        if (!m_TCPServer->listen(addr, port))
        {
            printLog("监听失败");
            return;
        }
        printLog(QString("开始监听，监听地址：%1:%2").arg(m_TCPServer->serverAddress().toString()).arg(QString::number(m_TCPServer->serverPort())));
        ui->pushButtonTCPStartListen->setText("停止监听");
        ui->comboBoxIPList->setEnabled(false);
        ui->lineEditPort->setEnabled(false);
        m_timerDataProcess.start(2000);
    }
    else if (m_TCPServer->isListening())
    {
        ui->pushButtonTCPStartListen->setText("开始监听");
        printLog("停止监听");
        ui->comboBoxIPList->setEnabled(true);
        ui->lineEditPort->setEnabled(true);
        m_TCPServer->close(); // 停止监听
        m_timerDataProcess.stop();
    }
}

void MainWindow::slot_TCPNewConnection()
{
    m_TCPSocket = m_TCPServer->nextPendingConnection();    // 创建socket
    if (nullptr == m_TCPSocket || !m_TCPSocket->isValid()) // 加判断套接字是否有效，客户端如果有心跳重连功能不判断会导致套接字失败
    {
        return;
    }

    socketThread = new ClassTCPThread(m_TCPSocket);
    socketThread->start();
}

void MainWindow::printLog(QString log1, QString log2)
{
    QTime timeNow = QTime::currentTime();
    QString data = QString("%1  %2  %3").arg(timeNow.toString()).arg(log1).arg(log2);
    ui->textEditLog->append(data);
    if (ui->checkBoxLogScrollToButtom->isChecked())
    {
        ui->textEditLog->moveCursor(QTextCursor::End);
    }
}

void MainWindow::slot_parseJSONData()
{
    if (dataQueue.length() > 0)
    {
        printLog("开始处理数据，共" + QString::number(dataQueue.length()) + "条");
    }

    while (!(dataQueue.isEmpty()))
    {

        QString data2 = dataQueue.dequeue();
        if (data2.length() < 100)
        {
            continue;
        }

        m_deviceData.initialize();

        QStringList lineList = data2.split('#');

        m_deviceData.qdtTime = QDateTime::currentDateTime();
        m_deviceData.deviceID = (lineList[0]);
        m_deviceData.APIKey = QString(lineList[1]);

        // 找到请求头的结束标志
        int bodyStart = lineList[2].indexOf("\r\n\r\n");
        QString requestBody;
        // 如果找到了请求头的结束标志
        if (bodyStart != -1)
        {
            // 提取请求体
            requestBody = lineList[2].mid(bodyStart + 4);
        }
        else
        {
            qDebug() << "未找到请求体";
            continue;
        }

        QByteArray ba = requestBody.toUtf8();
        const char *ch = ba.constData();

        cJSON *root = cJSON_Parse(ch);
        if (!cJSON_IsObject(root))
        {
            return;
        }

        cJSON *datastreams = cJSON_GetObjectItem(root, "datastreams");
        if (cJSON_IsArray(datastreams))
        {
            int numDatastreams = cJSON_GetArraySize(datastreams);
            for (int i = 0; i < numDatastreams; ++i)
            {
                cJSON *datastream = cJSON_GetArrayItem(datastreams, i);
                cJSON *id = cJSON_GetObjectItem(datastream, "id");
                cJSON *datapoints = cJSON_GetObjectItem(datastream, "datapoints");

                if (cJSON_IsString(id) && cJSON_IsArray(datapoints))
                {
                    QString idStr = id->valuestring;

                    cJSON *datapoint = cJSON_GetArrayItem(datapoints, 0);
                    cJSON *value = cJSON_GetObjectItem(datapoint, "value");

                    if (cJSON_IsNumber(value))
                    {
                        double doubleValue = value->valuedouble;

                        if (idStr == "Humidity")
                        {
                            m_deviceData.nHumidity = doubleValue;
                            m_deviceData.nGY39ValidFlag = 1;
                        }
                        else if (idStr == "Temperature")
                        {
                            m_deviceData.fTemperature = doubleValue;
                            m_deviceData.nGY39ValidFlag = 1;
                        }
                        else if (idStr == "Altitude")
                        {
                            m_deviceData.nAltitude = static_cast<int>(doubleValue);
                            m_deviceData.nGY39ValidFlag = 1;
                        }
                        else if (idStr == "Pressure")
                        {
                            m_deviceData.fPressure = doubleValue;
                            m_deviceData.nGY39ValidFlag = 1;
                        }
                        else if (idStr == "Illumination")
                        {
                            m_deviceData.nIllumination = static_cast<int>(doubleValue);
                            m_deviceData.nGY39ValidFlag = 1;
                        }
                        else if (idStr == "WindSpeed")
                        {
                            m_deviceData.fWindSpeed = doubleValue;
                            m_deviceData.nPR3000ValidFlag = 1;
                        }
                        else if (idStr == "WindDirection")
                        {
                            m_deviceData.nWindDirection = static_cast<int>(doubleValue);
                            m_deviceData.nPR3000ValidFlag = 1;
                        }
                    }
                }
            }
        }
        cJSON_Delete(root);

        emit signal_newData();
    }
    return;
}

void MainWindow::slot_updateUI()
{
    int rowCount = ui->tableWidgetDataList->rowCount();
    ui->tableWidgetDataList->insertRow(rowCount);

    ui->tableWidgetDataList->setItem(rowCount, 0, new QTableWidgetItem(m_deviceData.qdtTime.time().toString()));
    ui->tableWidgetDataList->setItem(rowCount, 1, new QTableWidgetItem(m_deviceData.deviceID));
    ui->tableWidgetDataList->setItem(rowCount, 2, new QTableWidgetItem(m_deviceData.APIKey));

    if (m_deviceData.nGY39ValidFlag == 1)
    {
        ui->tableWidgetDataList->setItem(rowCount, 3, new QTableWidgetItem(QString::number(m_deviceData.nHumidity)));
        ui->tableWidgetDataList->setItem(rowCount, 4, new QTableWidgetItem(QString::number(m_deviceData.fTemperature)));
        ui->tableWidgetDataList->setItem(rowCount, 5, new QTableWidgetItem(QString::number(m_deviceData.nAltitude)));
        ui->tableWidgetDataList->setItem(rowCount, 6, new QTableWidgetItem(QString::number(m_deviceData.fPressure)));
        ui->tableWidgetDataList->setItem(rowCount, 7, new QTableWidgetItem(QString::number(m_deviceData.nIllumination)));
    }
    else
    {
        ui->tableWidgetDataList->setItem(rowCount, 3, new QTableWidgetItem("-"));
        ui->tableWidgetDataList->setItem(rowCount, 4, new QTableWidgetItem("-"));
        ui->tableWidgetDataList->setItem(rowCount, 5, new QTableWidgetItem("-"));
        ui->tableWidgetDataList->setItem(rowCount, 6, new QTableWidgetItem("-"));
        ui->tableWidgetDataList->setItem(rowCount, 7, new QTableWidgetItem("-"));
    }

    if (m_deviceData.nPR3000ValidFlag == 1)
    {
        ui->tableWidgetDataList->setItem(rowCount, 8, new QTableWidgetItem(QString::number(m_deviceData.fWindSpeed)));
        ui->tableWidgetDataList->setItem(rowCount, 9, new QTableWidgetItem(QString::number(m_deviceData.nWindDirection)));
    }
    else
    {
        ui->tableWidgetDataList->setItem(rowCount, 8, new QTableWidgetItem("-"));
        ui->tableWidgetDataList->setItem(rowCount, 9, new QTableWidgetItem("-"));
    }

    for (int i = 0; i <= 9; i++)
    {
        ui->tableWidgetDataList->item(rowCount, i)->setTextAlignment(Qt::AlignHCenter | Qt::AlignVCenter);
    }

    if (ui->checkBoxDataScrollToButtom->isChecked())
    {
        ui->tableWidgetDataList->scrollToBottom();
    }
}

void MainWindow::on_pushButtonClearData_clicked()
{
    int rowNum = ui->tableWidgetDataList->rowCount();
    for (int i = 0; i < rowNum; i++) // 清空列表
    {
        ui->tableWidgetDataList->removeRow(0);
    }
    printLog("数据列表已清空。");
}

void MainWindow::on_pushButtonClearLog_clicked()
{
    ui->textEditLog->clear();
}
